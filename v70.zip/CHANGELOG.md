# CHANGELOG


## v74 — as costuras: a coisa que nunca esteve ali

O pedido tinha duas metades. A primeira eu tive de devolver.

### O final já era ele acordando

*"lembrando final do jogo se trata dele como acordado (...) tudo não passa de um
grande pesadelo"*. Fui olhar antes de escrever, e o final do jogo já termina
exatamente assim desde a v60:

```
"Hora de acordar."
"Ele abriu os olhos."
"Teto branco. Um aparelho apitando num ritmo que não era o dele."
"Quatro anos, e a casa, o gerador, a irmã que saiu buscar comida e nunca mais
 voltou — nada daquilo tinha acontecido fora da própria cabeça dele."
```

**Nenhuma linha do `FIM_CENA` foi tocada.** É a terceira vez nesta sessão que a
coisa pedida já existia, e depois do que eu fiz com o passo, olhar primeiro
deixou de ser opcional.

O que faltava era o **contrário**: durante os 30 dias o jogo nunca planta nada
que faça o jogador desconfiar. Os `SONHOS` existem — mas sonho é o lugar
*seguro* pra coisa estranha acontecer. A revelação chegava sem preparo.

### As costuras são esse preparo

Você está andando pela casa e uma coisa que você tinha certeza que estava ali não
está mais — e a casa age como se nunca tivesse estado.

> *"A viga não tem prego nenhum. A madeira é lisa onde você jurava ter visto o arame."*
> *"Debaixo do colchão só tem chão. O pó está uniforme, como se nada tivesse ficado ali."*
> *"A parede não tem nada escrito. E você lembra do número que estava lá."*

**Nove cômodos, dois objetos cada**, todos tirados do texto que o próprio jogo já
escreve em `AMBIENTE`. São coisas pequenas e inúteis de propósito — um prego
torto, uma caneca lascada, um pneu no muro.

### Por que isso não viola a regra de ouro

*"Se um evento não puder ser explicado pelo jogador depois que ele acontece, o
evento está errado."* Uma coisa sumindo como se nunca tivesse existido parece o
exemplo perfeito de evento inexplicável — e é o contrário: é o evento **mais**
explicável do jogo, porque o final inteiro existe pra explicar ele.

E até o final chegar, ainda é explicável por uma regra que o jogador aprende
sozinho:

> **Só some o que você viu sozinho.**

Coisa que outra pessoa da casa viu junto com você **não pode** ser desfeita. Isso
dá contra-jogo de verdade — andar acompanhado protege a sua memória — e não é um
número novo: é uma razão nova pra usar as pessoas que o jogo já tem.

### A lei que mantém isto justo

**Costura nenhuma mexe em contador.** Não tira comida, não tira material, não
fecha rota, não machuca, não gasta tempo. Ela tira o **fato**, não o recurso:
seus números não se movem, só a sua certeza.

Medido no teste: **9 costuras seguidas, zero contadores alterados** — comida,
diesel, remédio, ruído, sanidade, hora, reforço da porta, guardados, material,
ferramentas e males, todos parados.

Por isso a costura não precisa de tell antes: **não há dano pra avisar.** Punir
sem aviso é a proibição nº 9. Assustar sem aviso é o trabalho.

Os objetos existem só pra serem notados e desfeitos, e isso é de propósito: um
objeto útil que some vira punição, e punição aleatória é exatamente o que este
jogo não faz.

### Os limites que impedem o chuvisco

| limite | por quê |
|---|---|
| no máximo 2 por dia | a terceira vira chuvisco, que é o problema que o §37 já tinha diagnosticado na linha de saldo |
| nunca durante uma invasão | medo empilhado em medo vira ruído, não tensão |
| nunca fora de casa | a casa é o sonho |
| nunca duas seguidas no mesmo cômodo | repetição destrói a dúvida |
| **nunca no mesmo dia em que você viu** | ela some *entre* duas visitas, nunca na sua frente — se sumisse enquanto você olha seria efeito; assim é memória |

E quatro fases ao longo dos 30 dias, começando no dia 4. No dia 1, nada.

### A coda: o final passa a saber o que você perdeu

O final já dizia que nada tinha acontecido. Ele não sabia **quais** coisas o
jogador viu sumir. Agora sabe, e fecha nelas:

> *"Ele ficou um tempo tentando entender por que, de tudo, era isso que voltava primeiro."*
> *"Não a porta, não as batidas, não o gerador. Tinha um pneu velho encostado no muro, cheio de água parada — e o dia em que ele voltou naquele cômodo e não tinha mais nada ali."*
> *"Aconteceu 3 vezes, e ele lembra das 3. Foi a única coisa daquele mês inteiro que ele nunca conseguiu explicar pra si mesmo — e, agora, a única que faz sentido."*

São **linhas anexadas**, e só quando houve costura. Depois de rodar, `FIM_CENA`
volta a ter exatamente as 37 linhas que sempre teve — o teste confere.

### `docs/as-costuras.html` — dá pra fazer acontecer

Site animado com a casa dos nove cômodos jogável: você entra, repara nas coisas,
passa o dia, e vê uma sumir. O botão **“andar acompanhado”** demonstra a regra de
proteção ao vivo — medido no harness: **8 dias andando acompanhado, zero
costuras**. E um painel com os contadores reais do jogo ao lado, parados,
enquanto a casa te desfaz a memória.

O código de costura da página é copiado do `s49-costuras.js` **sem alterar
regra**.

### Verificação

`tools/testes/costurateste.mjs` (27) e `tools/testes/costsiteteste.mjs` (16).
A regressão completa fecha em **843 verificações, 30 harnesses, zero falhas**.

### Dois erros meus, os dois pegos pelo teste

**Escrevi `p.comodo`, e o campo é `p.local`.** A regra que protege a sua memória
**nasceu morta**: nada dava erro, a comparação simplesmente nunca era verdadeira,
e nenhum objeto ficava protegido.

**Testei a proteção numa casa sem ninguém dentro.** O teste reposicionava os
moradores — e `S.abrigo` estava vazio naquele ponto da partida. Zero pessoas,
zero protegidos, e o teste acusando o código de um bug que era do cenário.


## v73 — V71 Etapa 1: as decisões voltam pro gerador da partida

Primeira etapa do ULTRA_PROMPT V71. A Fase A (auditoria) está em
`docs/AUDITORIA-V71.md` e mudou o plano — o resumo dela vem no fim desta seção.

Esta etapa não adiciona monstro nenhum. Ela conserta a base de que todo o resto
depende: o §22 do documento é explícito, e o §30 põe **estabilidade e justiça
acima de identidade de ameaça**. Sem isto, nada do que vier reproduz.

### Achado 1 — a terceira grafia da mesma decisão

A v66 trocou `sortear` e `chance` pelo gerador semeado e varreu 71 sítios
diretos. Ela não pegou `Math.floor(Math.random()*n)`, que decide exatamente a
mesma coisa com outra cara. Em três casos o sítio semeado e o não-semeado
estavam **na mesma linha**:

```js
const q = 1 + Math.floor(Math.random()*3);   // ← não semeado
for(let i=0; i<(chance(.6)?1:2); i++){       // ← semeado
  const m = sortear(mats); darMat(m,q);      // ← semeado
```

O sorteio de saque era metade reproduzível.

Onze decisões de jogo estavam fora do gerador:

| o que decidia | onde |
|---|---|
| **a arma travar** | `atirar` — `if(Math.random()>conf)` |
| **qual sentido fica cego na noite** (SOM/ODOR/VISUAL/METAL) | `anoitecer` |
| **o padrão da batida na porta** — que é um *tell* de mímico | `batidaDe` |
| quanto material você acha | `vasculharPor` |
| quanto o ladrão leva de comida e de diesel | `roubarAlgo` |
| quantos turnos a fuga dura | `abrirFuga` |
| quanto o visitante espera na porta | `paciencia` |
| quando a mochila perdida reaparece | `tentarRecuperarLargada` |
| quantas casas tem na rua | `menuRuaCasas` |
| qual ilusão de sanidade sai | `sortearPesado` |
| a ordem das opções da escuta | `responderEscuta` |

As duas primeiras são as graves: a arma travar decide se você sobrevive, e o
sentido cego decide **qual criatura fica surda naquela noite**.

Entraram duas primitivas ao lado das duas que já existiam, com a mesma
distribuição e o mesmo arredondamento — **nenhum número de balanceamento muda**:

```js
const _inteiro = n => Math.floor(_ale()*Math.max(1,n|0));
function _embaralhar(a){ /* Fisher-Yates pelo gerador da partida */ }
```

`_embaralhar` substituiu um `sort(()=>Math.random()-.5)`, que **não é um
embaralhamento**: o comparador não é consistente e a ordem sai enviesada. Ali a
ordem é um tell, então vale ser justa. Medido: as 120 permutações de 5 elementos
saem, com desvio máximo de 1,8% em 40 mil tiros.

### Achado 2 — o estado do gerador era salvo, restaurado, e ignorado

Este só apareceu porque eu fui escrever o teste do primeiro, e é o maior dos dois.

`salvar()` grava `d.rngEstado`. `carregar()` copia **toda** chave do save pra
dentro de `S`, então `S.rngEstado` volta certo. Mas o gerador **vivo** (`S.rng`)
nunca era re-semeado a partir dele: `semearRNG()` roda uma vez, no parse do
`s30-nucleo.js`, que acontece **antes** de `carregar()`; e `rng()` só re-semeia
se `S.rng` tiver sumido.

Medido, plantando `123456789` no save:

```
depois de carregar()    S.rngEstado = 123456789    gerador = 999
depois de semearRNG()   S.rngEstado = 123456789    gerador = 123456789
```

Carregar um save retomava o sorteio de onde o **boot** parou, não de onde o
jogador parou. Tudo o que a v66 escreveu sobre reprodutibilidade valia só dentro
de uma sessão. Consertado com um embrulho de `carregar()` em `s30-nucleo.js`, que
semeia **depois** de a base copiar as chaves.

### A quinta trava de build

Verificada plantando a regressão de propósito, como as outras quatro. Ela roda
**depois** da montagem, sobre o `index.html` que embarca, e tira os comentários
antes de varrer — sem isso ela se acusava sozinha, porque o comentário que
explica a grafia proibida contém a grafia proibida.

`Math.random` cosmético continua permitido, mas agora precisa **se declarar**:

```js
if(Math.random()<.035) g=.25+Math.random()*.9;   /* cosmetico: a dobradiça engasgando */
```

Seis sítios foram marcados assim, cada um com o motivo escrito. Os outros 161
`Math.random` do arquivo são áudio e desenho e caem nas exceções da trava.

### Verificação

`tools/testes/rngteste.mjs` — 26 asserções. A regressão completa fecha em
**800 verificações, 28 harnesses, zero falhas**. Inclui reprodução com a mesma
semente, incluindo reprodução com a mesma
semente e o caminho de carga exercitado de verdade.

Três asserções deste harness falharam por erro **meu**, não do jogo, e as três
viraram linha no `LEIA-ME`: amostra pequena demais pro limite escolhido (N=3000
com limite de 12% é 3,3 sigma), e duas versões medindo a persistência *depois* do
boot, quando o boot legitimamente consome sorteios e o jogo legitimamente salva
de novo.

### O que a auditoria mudou no plano

`docs/AUDITORIA-V71.md`, medido contra o código:

- **§2, §4, §5, §10, §12, §13, §16, §17 e §26 já existem.** A "nova arquitetura
  de ameaças" é a descrição do `s26-anomalias.js`, que já tem identidade, máquina
  de estados, percepção, tell, evidência persistente e recorte serializável.
- **Três dos cinco invasores pedidos colidem** com criaturas existentes: o
  Imitante é o `imitador` + os sinais forjados do §40; o Cata-vozes é o `coro` +
  o chamado do `imitador`; o Rastejante de Parede é `rastejante` + a regra de luz
  do `magro` + os bloqueios de rota do §43.
- **Dois são genuinamente novos:** o Observador (inverte o incentivo de olhar,
  que nenhuma das seis faz) e o Hóspede (ameaça que não ataca e persiste entre
  noites, que nenhuma das seis faz).
- **Adoradores, facção e rituais não existem** — e têm semente pronta: o
  temperamento `supersticioso`, que já fala de sal na soleira há versões, e o
  documento do sal do §44 que transformou essa superstição em regra.


## v72 — o som mais perto da realidade

Primeira aplicação da skill de direção audiovisual no próprio jogo. Fase 0
primeiro: auditar antes de tocar em qualquer coisa. A auditoria funcionou — e
depois eu a ignorei uma vez, entreguei errado, e o teste me pegou.

### O que a auditoria achou — e o que ela mandou não fazer

A arquitetura de áudio deste jogo é boa, e **nada dela foi reescrito**:

```
A.ctx único → master com compressor → destino
barramento seco/molhado com convolver e reflexões precoces
mixer real de 5 camadas (voz, drone, evento, ambiente, gerador)
   com ducking automático por prioridade
saida(no, {pan, rev, vol}) roteia TODOS os sons — 101 sítios
```

### O erro que este bloco cometeu duas vezes

**Primeira vez, e eu peguei antes de entregar.** Escrevi um `somDePorta` próprio
em quatro camadas sem procurar se a porta já tinha som. Ela tem:
`somPortaAbrindo` monta **cinco** — ferrolho em duas voltas, rangido, arrasto,
lufada e batente. Removi a minha.

**Segunda vez, e eu entreguei.** Fiz exatamente o mesmo com o passo. Eu media
contra `passo()` da linha 474 do `index.html` e concluí que o passo do jogo era
*"um estalo só, sem material, sem variação"*. Aquele passo está **morto**: o
`audio-manager.js` declara outro depois dele, e o meu próprio `montar.js`
registra a troca por escrito:

```js
const COLISAO_OK=new Set([
  'passo',   // v48 troca o passo sintetizado pelo sistema de superfícies
```

O passo vivo é `passoEm()`, e ele já tinha tudo o que eu disse que faltava:

| o que eu "acrescentei" | o que já existia lá |
|---|---|
| segunda batida 45–75 ms depois | o pé arrastando, 50–90 ms depois |
| material do piso | quatro superfícies com corte, Q, corpo e ressonância |
| ressonância de assoalho oco | *"a tábua respondendo depois"*, com esse comentário |
| variação por disparo | `Math.random` em frequência, ganho e tempo |

Eu troquei o bom pelo meu, mais pobre, e publiquei que tinha melhorado.
**Minha versão foi removida. O passo do jogo é o `passoEm` de novo.**

### O que sobrou — e que é de verdade o que faltava

**1 · `saida()` não tinha modelo de distância.** Som longe só ficava mais baixo.
Mas o que o ouvido usa pra julgar distância é a **perda de agudo** — o ar absorve
alta frequência, e é por isso que trovão longe é um ronco e trovão perto é um
estalo. Como `saida()` é o roteador universal, resolver ali serve os 101 sítios:

```
0 cômodos → 18000 Hz   (transparente)
1 cômodo  →  8100 Hz
2 cômodos →  3645 Hz
3 cômodos →  1640 Hz
4 cômodos →   738 Hz
```

É **opt-in**: sem `dist`, o caminho é byte a byte o de antes — medido, zero nós a
mais.

**2 · O sistema de superfícies não chegava nos cômodos.** Este é o achado que
valeu a rodada. `pisoDaCena()` decidia o piso assim:

```js
if(c===10)return 'terra';         // quintal
if(c===0||c===9)return 'escada';  // sótão e porão
return 'madeira';
```

O abrigo tem os cômodos **0 a 8**. O quintal é 8, não 10. O porão é 6, não 9.
Resultado medido:

| | antes | agora |
|---|---:|---:|
| cômodos que soavam a madeira | **8 de 9** | 3 de 9 |
| superfícies distintas no abrigo | **2** | 6 |

O motor era bom e estava apontando para índices que não existem. Duas
superfícies novas entraram, e as duas saíram do texto que o próprio jogo escreve
em `AMBIENTE`:

> cômodo 1 — *"Colchões no chão."* → **colchão**
> cômodo 5 — *"Fogão a gás com meio botijão."* → **ladrilho**
> cômodo 8 — *"Muro alto, portão soldado, terra batida."* → **terra**

**3 · Nem passo nem porta tinham distância.** `passoDistante()` existe no jogo, e
um passo distante só ficava mais baixo. Agora `passo(proximidade, pan)` deriva
distância da proximidade e o passo atravessa ar. Isto **muda** o som dos sítios
que já chamavam com proximidade baixa, e muda de propósito. A porta ganhou o
mesmo por `comDistancia(d, fn)`, sem que uma linha do corpo dela mudasse.

### Custo — contado, não cronometrado

Publiquei antes que o passo tinha ficado mais barato (0,921 → 0,357 ms). Era
falso **duas vezes**: eu media o *antes* num `AudioContext` já cheio de nós
vivos, e o *antes* que eu media era o passo morto. Repetindo a **mesma** chamada
seis vezes seguidas:

```
1,70 · 2,35 · 4,83 · 4,68 · 6,24 · 6,24 ms
```

para código idêntico. O cronômetro media acúmulo de nós. **Toda asserção de tempo
saiu do teste.** O que ficou é contagem, que é determinística:

| | perto | com distância | custo |
|---|---:|---:|---|
| passo | 18 nós | 22 nós | +4 — um filtro por camada |
| porta | 48 nós | 58 nós | +10 — um filtro por camada |

Nenhuma camada se perde em nenhum dos dois. O que se perde é brilho.

### `docs/laboratorio-de-som.html` — dá pra ouvir cada item deste changelog

Uma página que **toca os sons do jogo**, som por som: o passo morto contra o
passo vivo, os nove cômodos um a um nos dois mapas de piso, a mesma porta a cinco
distâncias, e as cinco camadas dela separadas. Com osciloscópio ao vivo e um
botão que percorre tudo sozinho.

O motor de áudio dela é copiado do `index.html` **sem alteração de uma linha** —
a cadeia, o roteador `saida`, `passoEm` com as superfícies e as cinco camadas da
porta. Uma página que demonstrasse sons *parecidos* com os do jogo não provaria
nada. `tools/testes/labteste.mjs` (26 asserções) conta as camadas de cada som e
confere os cortes do filtro de ar, pra que ela não envelheça em silêncio.

### Política respeitada

Áudio cosmético continua com `Math.random`, como o `s30-nucleo.js` declarou por
escrito. Nada aqui gasta o RNG da partida.

### Verificação

`tools/testes/somteste.mjs` — 35 asserções, mais 26 em `labteste.mjs`. A
regressão completa fecha em **774 verificações, 27 harnesses, zero falhas**.

O `somteste.mjs` carrega no topo, em comentário, a história de ter testado a
coisa errada — porque foi ela que custou a entrega.

Três asserções foram trocadas por medida determinística depois de passarem pelo
motivo errado: o corte máximo entre **todos** os filtros (que escondia o filtro
que eu tinha acabado de adicionar), e duas razões de tempo que passaram numa
rodada e falharam na seguinte sem regressão nenhuma no meio.


## v71 — as etapas 5 a 8, e três bugs de tela

Entrou junto e por isso nunca teve seção própria aqui. Fica registrado.

- **§43 · voltar é o segundo jogo.** Entrar em camada ≥3 pergunta uma vez por
  dia — *"Você ainda consegue voltar. Depois disso, eu não sei."* — e a rota de
  volta ganha bloqueio: porta emperrada, corredor alagado, entulho, ou alguma
  coisa posicionada. Atravessar custa 9 minutos e 3,5 de ruído.
  `retornoTemSaida()` prova, a cada bloqueio, que ainda há caminho até o núcleo:
  o preço de voltar é o desvio, **nunca a prisão**.
- **§44 · documento que não muda regra é enfeite.** Sete documentos que revelam
  regra que o resto do jogo lê de verdade — o sal barra o Rastejante, a luz para
  o Magro, a porta da cozinha às 03:00. E **uma regra falsa por campanha**: a
  planta da ala leste, que faz o jogador andar 35% mais barulhento no caminho
  que ele acha seguro, com um segundo documento que a corrige. O documento do
  sal cita a superstição que os moradores já falavam há versões.
- **§45 · sobreviver te torna mais frágil e mais visado.** Cicatriz não some, e
  a casa mira nela: 73/300 → 156/300.
- **§46 · quem trata você tem poder sobre você.** Cinco tratamentos, e o
  cuidador tem `tell` próprio — o Imitador tratando você é a cena mais barata
  de escrever e a mais cara de sobreviver.

Mais três bugs de tela achados por varredura, não por relato.

## v70 — pressão, luz e exposição (Etapa 4 de 9)

A Etapa 1 deixou dois campos declarados em `custoDeEntrada()` com valor zero e o
motivo escrito ao lado: `luz` e `exposicao`. Não foi esquecimento — os
consumidores delas não existiam, e ligar parâmetro sem consumidor é a proibição
nº 5 do briefing. Agora os consumidores nascem, e os dois campos cobram.

### A pressão, e os quatro degraus

Sobe fora do núcleo, decai **só** no núcleo, e nunca aparece como número. O que
o jogador recebe são os quatro degraus do A3, e a casa fala **uma vez por
subida** — repetir a mesma linha todo turno viraria chuvisco, que é o problema
que o §37 já tinha diagnosticado na linha de saldo.

> *"A luz oscila uma vez, curta, e volta."*
> *"A porta que você deixou aberta está encostada."*
> *"O barulho parou todo de uma vez. Isso é pior do que o barulho."*

### Quatro perfis, um dia cada — medido

Eu desconfiei que os números estivessem altos e fui medir quatro rotas
plausíveis de um dia inteiro. A medição desmentiu a suspeita:

| perfil | tempo andando | pressão | degrau | atenção | picos |
|---|---:|---:|---|---:|---:|
| caseiro (cozinha, quarto, sala) | 49 min | 0,00 | calma | 0,09 | 0 |
| trabalhador (oficina, despensa) | 87 min | 0,29 | calma | 0,37 | 0 |
| fuçador (desce ao porão às vezes) | 100 min | 0,42 | estalos | 0,46 | 0 |
| **obsessivo (vive no porão e no quintal)** | 154 min | **0,94** | **a casa parou de avisar** | 0,86 | **1** |

É exatamente o desenho: quem fica em casa não sente nada; quem vive no fundo
acorda a casa. A curva virou asserção — ela **é** o contrato, não um efeito
colateral.

E responde ao critério de aceite *"existe pelo menos uma situação por noite em
que não explorar é a jogada correta"*: no último degrau, existe.

### O vale obrigatório reusa o silêncio que o §31 já sabia fazer

Cruzar 0,80 abre o pico e dá **crédito de orçamento** ao orquestrador — ele
passa a poder gastar acima do teto da noite, até um limite declarado. Cair
abaixo de 0,60 fecha o pico e **empurra um vale na lista do §31**, zerando o
crédito.

Não inventei mecanismo de silêncio: o §31 já agenda vales em turnos e
`pedirPermissao` já os consulta. Silêncio continua sendo conteúdo reservado, não
o que sobra. O teste prova a regra dura: **todo pico gera um vale.**

### Luz: enxergar custa, e o escuro custa outra coisa

```
cômodo aceso  →  luz 0,61 de diesel · sanidade −1,0
cômodo escuro →  luz 0     de diesel · sanidade −1,4  ·  +pressão
```

É o A2 escrito: no escuro é mais barato e muito pior. O consumível é o diesel do
gerador, que já existia — não inventei recurso novo.

### Exposição: a casa acorda com o que viu

`atencaoDaCasa` sobe com profundidade e barulho, e vira orçamento na noite
seguinte:

```
atenção 0,86  →  +24 de orçamento  (113 → 137)
```

**Sem furar o teto do §31.** Acordar a casa não fura o limite que ela já
prometia — `ORQ_CFG.orcamentoTeto` continua sendo a última palavra. E a atenção
esfria sozinha entre noites, senão viraria catraca: quem explorou muito uma vez
ficaria marcado pra sempre.

### A terceira vez que a guarda de colisão salvou uma etapa

`pressao()` **já existe** em `index.html:12589` — e é outra coisa inteira: a
pressão da **dificuldade** (*"menos gente lá fora quer dizer mais coisa que não é
gente"*), que devolve 1 ou mais e alimenta a curva do jogo.

Sombreá-la teria quebrado a dificuldade em silêncio, sem erro nenhum. O acessor
aqui é `pressaoAgora()`; o campo de estado continua sendo `S.exploracao.pressao`,
que é o nome do briefing. Colide só o acessor.

Antes desta: `ANCORAS` no §38, `SINAIS` no §40.

### Verificação

`tools/testes/pressaoteste.mjs` — 31 asserções. Regressão completa: **654 ok, 0 falhas, 23 harnesses.**

## v69 — um corpo só (Etapa 3 de 9)

### Dois sistemas de ferimento, e um deles contava a mesma pancada de novo

A auditoria mediu: o jogo tinha `MALES` — 19 entradas com `grav`, `dias`, `faz`,
`custa`, `trata`, `pior`, `vem`, `urgente`, `pega` e `mata`, onde o "verbo
perdido" do B3 **já estava implementado**. E tinha `S.ferido`, um inteiro escrito
em 12 sítios com cura própria em `sararUmPouco`, que não falava com
`passarSaude`.

Em três desses sítios o código fazia as duas coisas:

```js
const fer = ferirPor('bicho');                 // cria um mal de verdade
if(fer) diz(`Você ficou com ${fer.n}...`);
S.ferido = (S.ferido||0) + f;                  // e conta de novo, à parte
```

A mesma pancada, duas entradas, dois relógios de cura independentes.

### Os 12 sítios, convertidos um a um

Os três de contabilidade dupla perderam a linha do contador — o mal já existia.
Os outros nove passaram a criar o mal que a própria ficção deles já nomeava:

> *"Você se corta no caco ao passar."* → `ferirPor('obra')`
> *"A telha cede e você desce mais rápido do que queria."* → `ferirPor('queda')`
> *"Ela agarra o cabo e puxa."* → `ferirPor('bicho')`

E a cura paralela morreu: o remédio de `sararUmPouco` agora **trata um ferimento
de verdade**, escolhendo o pior primeiro. Quem conta os dias é o `passarSaude`,
que já existia e já fazia isso certo.

**`S.ferido` virou derivado.** As 8 leituras espalhadas pelo jogo — o odor que a
casa sente, a fala do abrigo *"você tá mancando faz dias"*, o placar do fim —
continuam funcionando, agora lendo de `MALES`. Escrever nele não quebra nada e
não faz nada, mas fica registrado: qualquer sítio que eu tenha deixado passar
aparece no teste em vez de ressuscitar o sistema paralelo em silêncio.

### Toda ferida tem endereço

Sete partes, com lateralidade, e o tipo do mal decide onde cai — não é sorteio
livre, é o lugar que a ficção já sugeria (`torcao` é "torção no pé", `pancada`
vai pra cabeça ou o peito):

```
corte       braco_esq       → bracos
cortefundo  perna_esq       → pernas
torcao      perna_esq       → pernas
fratura     perna_dir       → pernas
queimadura  mao_dominante   → bracos
mordida     braco_esq       → bracos
pancada     torso           → torso
```

`REGIOES` (as cinco regiões que a armadura já cobria) continua existindo, e
`regiaoDaParte` liga uma coisa na outra. Onde dói e o que a roupa protege são
perguntas diferentes.

### Os três parâmetros mortos morreram

**`custa.atencao` era mentira impressa.** Quatro males cobravam, o código travava
o valor, **escrevia "atenção −35%" na ficha do jogador** — e nenhuma regra lia.

Agora ela custa o que o nome diz: **percepção**. O consumidor nasceu na etapa
passada — a antecedência dos sinais do §40. Medido:

```
atenção cobrada 0,55 · antecedência 6 → 2,7
o cheiro do Inchado vinha a 3 cômodos, agora vem a 1
```

Cabeça batida faz o aviso chegar mais tarde. A trava de justiça continua valendo
por cima: **a iminência nunca cai abaixo de 2 turnos**, nem com a cabeça aberta.

**`custa.agua`** só era cobrada por `barriga` e ninguém lia. Agora a barriga
desidrata: o gole a mais sai do galão, todo dia.

**`MALES.dente`** era o único dos 19 que nenhuma tabela alcançava. Comida ruim e
meses sem escova são a fonte que a ficção já pedia. **19 de 19.**

### O jogo parou de mostrar número de vida

Três lugares imprimiam porcentagem de corpo. O pior era a ficha:

> ~~No total: força −28% · fugir −30% · atenção −35%~~

Isso falhava em três coisas de uma vez: é número de estado do corpo na tela; não
diz ao jogador **o que** ele perdeu, que é o teste do B3; e a `atenção −35%` era
falsa. Agora:

> *"Torção no pé na perna direita. Você manca. Correr é uma decisão, não um
> reflexo."*
> *"Corte fundo na mão boa. A mão treme no que exige precisão: tranca,
> curativo, fósforo."*
> *"Febre. Você fica fraco e com frio no meio do calor."*
> *"Você levanta tarde. São 2h a menos de dia útil."*

Varredura final: **zero** porcentagens de corpo no jogo inteiro.

*(A primeira versão escrevia "Torção no pé **em a** perna direita". A contração
importa mais aqui do que em qualquer outro lugar: esta é a frase que substituiu
"força −28%", e ela só vale a troca se soar como alguém falando.)*

### Verificação

`tools/testes/corpoteste.mjs` — 29 asserções. Regressão completa: **622 ok, 0 falhas, 22 harnesses.**

## v68 — sinais viram contrato (Etapa 2 de 9)

### O problema não era falta de sinal

A auditoria achou **14 sinais já escritos** no jogo: 8 em `AMEACAS.aviso` e 6
em `REGRA.dica`. Todos bons, todos escritos à mão. E todos **texto solto** — sem
fase, sem canal, sem antecedência, sem identidade.

Ninguém conseguia perguntar *"houve sinal antes disto?"*. Por isso a asserção
central do briefing — **tell antes de dano** — não era verificável. Não é que o
jogo punisse sem avisar: é que ele não tinha como **provar** que avisou.

Esta etapa não inventa prosa por gosto. Dá estrutura ao que existia e completa
as fases que faltavam.

### As 24 linhas

Seis criaturas × quatro fases: duas de aproximação, uma de iminência, uma de
contato. Cada uma com canal (áudio, visual, tátil, olfato, ausência),
antecedência, modo de degradação e — quando falsificável — a **inconsistência**
pela qual a isca pode ser lida.

Uma aproximação do Inchado, medida:

```
4 cômodos · nada ainda
3 cômodos · "Cheiro doce e parado, enjoativo, mais forte do que estava."
2 cômodos · "Respiração úmida, no mesmo compasso, sem nunca variar."
1 cômodo  · "A parede do cômodo do lado está escorrendo."   ← IMINÊNCIA
0         · contato
```

### Antecedência deixou de ser número morto

Ela vira **distância de disparo**: antecedência 6 aparece a 3 cômodos,
antecedência 2 aparece a 1. Sanidade baixa encurta a antecedência, então o aviso
chega mais perto — e o jogador sente isso sem abrir ficha nenhuma.

| sanidade | aproximação | iminência | falsos/noite |
|---|---:|---:|---:|
| 1,0 | 4,0 | 2 | 0 |
| 0,7 | 3,2 | 2 | 1 |
| 0,4 | 2,4 | 2 | 2 |
| 0,1 | 1,8 | **2** | 3 |

**As duas travas de justiça, testadas:** a iminência nunca cai abaixo de 2
turnos, em nenhuma sanidade; e sinal falso **soma**, nunca substitui um
verdadeiro. Cabeça ruim gera ruído, não cegueira.

O Primordial é o único que **melhora** com a sanidade baixa — quem está inteiro
não percebe que o som sumiu. É o desenho dele, e está no teste.

### A isca não pode mentir sobre o último aviso

Duas regras, ambas por construção, ambas testadas:

- a casa pode forjar **aproximação**; iminência forjada é recusada pela API;
- sinal forjado **sem inconsistência declarada** é recusado. Isca cega é
  proibida — se o jogador não tem como desmascarar, não é jogo, é castigo.

E sinal forjado **não conta como aviso** em `foiEmitido`. A casa não pode
comprar o direito de te machucar mentindo.

### As duas decisões da tabela, aplicadas

**O Magro não foi invertido.** A tabela pedia "apagar a luz" como contra-jogo.
No jogo, `REGRA.magro.evita(id)` devolve `luzLigadaEm(id)` e a dica que o
jogador já leu diz *"ele para na porta de cômodo aceso e não entra"*. Apagar
hoje **abre** o cômodo pra ele. Os sinais entram inteiros; o contra-jogo fica
sendo o do jogo.

**O Coro tem duas bocas, não três.** `BICHOS.coro` tem `dois:true`. A contagem
cai de 2 para 1.

### A trava, dividida em duas metades honestas

O briefing pede que *tell antes de dano* seja **falha de build**. Uma guarda de
build não consegue provar emissão — isso é tempo de execução. Então:

- **build** (`montar.js`, quarta guarda): a integridade da tabela. Toda criatura
  em ≥2 canais, toda criatura com iminência, nenhuma iminência omitível, todo
  falsificável com inconsistência. As três regras foram verificadas quebrando a
  build de propósito, uma por vez.
- **execução** (`§40`): `pegarMal` embrulhado. Ferimento causado por criatura sem
  sinal anterior conta violação, e o teste exige zero.

Escopo declarado: vale para as 6 criaturas da casa. Queda, fogo e obra não são
criaturas e têm o próprio aviso na cena que os causa.

### Duas armadilhas que eu mesmo já tinha anotado, e caí nas duas

**A guarda de build acusou o inocente.** Ela fatiava a tabela até o primeiro
`];` — e dentro de `monta` existe `(S.abrigo||[])[0];`, cujo `0];` casou. Lia 14
dos 24 sinais e acusava o Imitador de ter um canal só. O fim do array é `];` em
**início de linha**. Guarda que acusa o inocente é pior que guarda nenhuma.

**O teste pôs o jogador na SALA.** A SALA é o miolo da planta: nada fica a mais
de 2 cômodos dela. Todas as posições davam distância 1, então a fase de
aproximação nunca acontecia e o teste falhou por construção. O par mais distante
da casa é SÓTÃO–QUINTAL, distância 4. **Está escrito no LEIA-ME dos testes desde
o §31**, e eu caí nele mesmo assim.

### Nome

A tabela chama-se `TELLS`, não `SINAIS` — porque `SINAIS` **já existe** em
`index.html:17685`, e é o cheiro de cada lugar da expedição (*"cheiro de giz e
amônia"*, *"o ar é doce demais pra um lugar desse"*). Conceito diferente, nome
igual: num escopo de 1473 nomes, o segundo apagaria o primeiro em silêncio e as
expedições perderiam o cheiro.

A guarda de colisão pegou na hora. É a **segunda vez** que ela salva uma etapa —
a primeira foi `ANCORAS`, no §38.

### Verificação

`tools/testes/sinaisteste.mjs` — 33 asserções. Regressão completa: **593 ok, 0 falhas, 21 harnesses.**

## v67 — o passo custa (Etapa 1 de 9)

Primeira fatia do plano de Exploração + Ferimentos. Uma etapa por vez, cada uma
fechando sozinha. O plano inteiro está em `docs/PLANO-EXPLORACAO-CORPO.md`.

### A falha crítica

A auditoria mediu, atravessando os 10 cômodos da casa e voltando:

```
hora 0 · minutos 0 · ruído 0 · sanidade 0 · diesel 0
```

**Zero nas cinco dimensões.** `irPara` movia o jogador, redesenhava o cômodo e
listava quem estava lá — sem chamar `gastarHoras`, sem chamar `gastarRuido`, sem
tocar sanidade nem bateria. Nada impedia varrer a casa inteira todo turno.

E sem custo de passo, camada, pressão e ponto de não retorno não têm em que se
apoiar. Por isso esta é a primeira etapa e não a quarta.

### O relógio, antes de tudo

`S.minutos` já existia e já era somado em dois lugares — mas só **um** deles
fazia o rollover para hora, e `horaTexto()` escrevia `HH:00` sempre, jogando os
minutos fora na tela.

Com o passo cobrando minutos isso deixa de ser detalhe: se o jogador não vê o
tempo que gastou andando, o custo é invisível e vira punição sem leitura. Agora
há um caminho só, `gastarMinutos()`, e o mostrador conta a verdade.

### As camadas

```
0 núcleo   SALA · QUARTO
1 casa     COZINHA · ENTRADA
2 bordas   DESPENSA · OFICINA · SÓTÃO
3 anexos   PORÃO · QUINTAL
4 fora     a expedição, que já era outro sistema
```

O QUINTAL é 3 e não 4 de propósito: tem `saida:true` e é a soleira para a rua,
mas ainda é o seu quintal.

### O que o passo cobra

| | núcleo | casa | borda | anexo |
|---|---:|---:|---:|---:|
| tempo | 4 min | 7 min | 10 min | 13 min |
| ruído | 0 | 1,1 | 2,2 | 3,3 |
| sanidade | +0,35 ao voltar | 0 | −0,5 | −1,0 |

Um dia tem 720 minutos. Atravessar a casa de ponta a ponta é barato — o que
encarece é **insistir**. A intenção não é racionar passo: é o jogador sentir a
noite chegando enquanto decide.

E o corpo já entra: **ferido anda pior**, medido — 13 min → 20 min e mais
barulho, lendo `custa.forca` e `custa.ruido` que a tabela `MALES` já tinha. É o
laço 2 da Fase 3 do briefing, de graça, porque o dado já existia.

### O que não entrou, e por quê

**Luz e exposição.** Os consumidores delas — gasto contínuo de luz e
`atencaoDaCasa` ligada ao orçamento do §31 — são da Etapa 4. Ligar agora criaria
dois parâmetros mortos, que é a proibição nº 5 do próprio briefing. Elas aparecem
no objeto de `custoDeEntrada()` com valor zero e o motivo escrito ao lado: são
contrato declarado com data de entrada, não esquecimento.

### Eu reintroduzi o save fantasma da v60, e o teste pegou

Vale registrar porque é a mesma armadilha em roupa nova.

O bloco anexa `d.exploracao` ao save. A primeira versão chamava `estadoExp()`,
que **cria** o ramo quando ele não existe. Resultado: qualquer `marcarSujo()` que
rodasse no boot, antes de `carregar()`, gravava um ramo vazio **por cima** do que
estava salvo. Os passos do jogador voltavam a zero.

E havia uma segunda forma do mesmo bug: o `salvar()` da base tem
`if(!S.nomeJogador)return`, e o meu wrapper não repetia essa guarda — então ele
gravava mesmo quando a base tinha desistido. Wrapper que grava onde a base não
gravaria é save fantasma com outro nome.

> **Bloco ANEXA a um save; bloco nunca CRIA estado — e nunca grava onde a base
> não gravaria.** A regra da v60 ganhou a segunda metade.

Efeito colateral bom: `S.trilha` — o rastro do jogador, que a auditoria achou
fora do save — agora persiste. É pré-requisito do `rastroSangue` da Etapa 7.

### Migração

`S.exploracao` nasce com `schemaVersion:1` e migração idempotente. Save antigo
ganha o ramo com **todos os cômodos marcados como conhecidos** — quem já jogava
conhece a casa, e marcar tudo como nunca visitado transformaria veterano em
novato. Campo de save futuro que eu não conheço é preservado, não descartado.

### Verificação

`tools/testes/passoteste.mjs` — 30 asserções. Regressão completa: **560 ok, 0 falhas, 20 harnesses.**

Duas falhas da primeira rodada eram bug do teste, e as duas são armadilhas já
anotadas: medir sanidade sem contar `v9().escudo` (os 30 pontos que absorvem a
primeira queda), e medir o bônus de voltar ao núcleo indo de núcleo para núcleo.

## v66 — os consertos

Pedido: *"resolva todos os bugs do jogo, absolutamente tudo."* Fui atrás por
medição, não por leitura. O que segue é o que estava quebrado, com a prova.

### O bug de raiz: 612 decisões fora do gerador da partida

O jogo tem um RNG semeado completo. `criarRNG` com `next`, `inteiro`,
`escolher` e `pesado`. `semearRNG()` deriva a semente de `(saveId, dia)`. O
estado vai pro save em `d.rngEstado` e volta na carga. E `s30-nucleo.js` declara
a política por escrito:

> *"RNG SEMEADO no que decide jogo; cosmético fica com `Math.random`."*

Máquina inteira montada, testada, persistida. E então:

```js
const sortear = a => a[Math.floor(Math.random()*a.length)];
const chance  = p => Math.random() < p;
```

**As duas portas de entrada nunca foram ligadas nela.** São 397 chamadas de
`chance()` e 215 de `sortear()` — **612 decisões**, praticamente todas as do
jogo — passando por `Math.random()`, enquanto o gerador determinístico rodava ao
lado sem ninguém chamar.

É exatamente a forma do estágio `tenso` da sanidade: a promessa escrita no
código e o código garantindo que ela não vale.

Agora as duas passam por `_ale()`, que usa o gerador da partida e cai em
`Math.random` só enquanto o `rng` ainda não existe (os blocos são injetados no
fim do body). Mais 71 chamadas diretas em 46 funções que decidem estado — loot,
clima, evento, criatura, visitante, quem some do mundo. A distribuição é
idêntica: **nenhum número de balanceamento mudou.** O que muda é que o resultado
para de depender de sorte que o save não conhece.

Uma ficou de fora de propósito, e está comentada no código: a cauda de reverb em
`gerarImpulso` gera dezenas de milhares de amostras por chamada. Passar isso pelo
gerador gastaria o RNG num laço de áudio e faria a sequência do jogo depender de
o som ter inicializado.

**Guarda de build nova.** Essa regressão seria um caractere, sem erro, sem teste
vermelho, e só apareceria como "esse save não reproduz". Então o `montar.js`
agora quebra a build se `sortear`, `chance` ou `_ale` saírem da forma semeada —
verificado plantando a regressão de propósito.

### Perda de progresso: três estados morriam no recarregamento

Este precisou de duas medições, porque a primeira **passou pelo motivo errado**.

`carregar()` não reconstrói o `S`: copia as chaves do save por cima do `S` que já
está na memória. Então `salvar(); carregar()` na mesma página preserva tudo —
inclusive o que nunca foi gravado. Só um `page.reload()` de verdade mostra:

```
ANTES   tarefas:4  objetivos:1  ignorado:4  vigiou:true  infiltrado:"Rafael"
DEPOIS  tarefas:0  objetivos:0  ignorado:—  vigiou:false infiltrado:null
```

A pior é `objetivos`, porque ela carrega o contador `ignorado` — e é ele que
decide se a pessoa sai de madrugada atrás do que quer e morre. **Alguém a quatro
passos disso voltava em zero toda vez que o jogador fechava o app.**

### O Imitador disfarçado de mecânico ganhava o bônus do mecânico

`S.infiltrado` era uma **referência** pra dentro de `S.abrigo`. Depois de
qualquer ida-e-volta por JSON, o abrigo tem objetos novos e a referência aponta
pra um fantasma. Nada reclama.

Havia remendo dentro de `pistaDoDia` — `p.falso` como backup, com o comentário
explicando. Mas só valia ali. Em `desgastarGerador`:

```js
if(tem('mecânica') && quem('mecânica')!==S.infiltrado) d*=.55;
```

Depois de um recarregamento esse `!==` é sempre verdadeiro, e **a coisa que
substituiu o Rafael continuava cuidando do gerador como o Rafael.**

Agora a chave é o nome, como já era em tarefas, laços e dono.

### Três habilidades prometiam na ficha e não tinham uma linha de código

`ef` é o texto que o jogador lê na ficha da pessoa. Para três das doze, o texto
prometia algo que o jogo nunca fazia. Verificado por busca dos pontos de consulta
(`tem('x')` / `quem('x')`):

| pessoa | habilidade | o que a ficha promete | consultas |
|---|---|---|---|
| **Nice** | `costura` | *"Remenda tudo. Reforço não se perde."* | **0** |
| **Juninho** | `escalada` | *"Expedições rendem 25% a mais."* | **0** |
| **Kelly** | `corrida` | *"Expedições fazem menos ruído."* | **0** |

As três agora fazem o que está escrito, com os números que já estavam escritos —
os 25% são os 25% da ficha. A Nice remenda a tábua que soltou por dano; a que o
jogador arranca de propósito pra virar material continua saindo, porque ali a
perda é escolha dele.

### Dois parâmetros mortos

**`p.mem`** — as doze pessoas carregam um campo com aquilo de que sentem falta:
*"a igreja da praça"*, *"a oficina do pai dele"*, *"o cachorro dele, Pipoca"*, *"a
viatura 14"*. **Lido zero vezes no jogo inteiro.** O material mais rico do
arquivo de dados dos NPCs, inerte desde sempre.

**`p.escondeu`** — a pessoa desmoralizada desvia lata da despensa, o contador
sobe, e ninguém nunca lê. Ela podia desviar a campanha toda sem consequência
nenhuma: nem pra ela, nem pra despensa, nem pro jogador.

Agora o esconderijo é real — o terceiro desvio é descoberto e custa laço, e o que
ela guardou volta pra casa quando ela morre.

E `p.mem` virou a rotina **`saudade`**, que existe por dois motivos medidos:

> Numa campanha de 30 dias o jogador via **5 das 16 rotinas**. Não é sorte:
> `conserta` pede avaria, `horta` pede canteiro, `ajuda` pede doente, `lembra`
> pede morto. Numa casa sem crise o poço seca para
> `{organiza, cozinha, vigia, ensina, reza}` — que são exatamente as cinco
> medidas.

`saudade` não pede nada da casa e vale em toda faixa de moral. É variedade na
casa calma sem mexer no peso de ninguém.

### Vazamentos

- **Objetivo órfão.** `cobrarObjetivos` fazia `return` quando o dono tinha saído
  do abrigo, e a meta ficava na lista pra sempre — sem dono, sem prazo, contando
  `ignorado` que ninguém ia cobrar. Agora encerra junto com a pessoa.
- **`local` fora da planta.** A pessoa some de todo cômodo e continua viva: não
  aparece em lugar nenhum, não dá erro, e o jogador acha que ela sumiu. Era
  saneado só no `carregar()`, então quem recebesse um local ruim durante a
  partida ficava invisível até fechar e reabrir o jogo.

### Verificação

`tools/testes/bugteste.mjs` — 24 asserções, uma por conserto, incluindo o
recarregamento de página de verdade.

Registro de método: a primeira rodada do teste de determinismo **falhou por bug
meu** — o gerador de sequência resetava a semente lá dentro, então a comparação
de "semente diferente" comparava a mesma semente com ela mesma. Corrigido no
teste; o código estava certo.


## v65 — a sanidade vira sintoma

### O pedido

*"Quero melhorias gigantescas na parte da sanidade e ilusões, elas tão muito
sutis e sem sentido."*

Os dois adjetivos estavam certos, e por motivos diferentes. Fui medir antes de
escrever qualquer linha.

### Sutil: o estágio onde o jogador mais vive produzia zero

O jogo tem 23 ilusões (6 de tela, 8 de rua, 9 de som). `talvezIlusao` roda uma
vez por dia, com trava de uma por dia, e a chance é o próprio valor de ilusão
do estágio. Numa campanha inteira de 12 a 30 dias o jogador vê **entre duas e
seis**.

Isso já é pouco. O que estava embaixo é pior:

```
estágio        san≥   ilusão   ilusões no pool
  lúcido         90     0.00        0   (correto — lúcido é lúcido)
  tenso          70     0.08        0   ← MORTO
  fissurado      45     0.22       13
  rachado        20     0.40       20
  desfeito        0     0.55       23
```

O menor `min` das três tabelas é `0.10`. O estágio `tenso` vale `0.08`.

```js
pool = ILUSOES.filter(i => 0.08 >= i.min)   //  →  []
```

**Um off-by-0.02 apagava a faixa inteira de sanidade 70–89** — que é onde o
jogador passa a maior parte do jogo. E o estágio prometia por escrito, na
tela dele:

```js
'tenso': 'Você ouve passo onde não tem passo.'
```

O jogo dizia que ia acontecer e o filtro garantia que não acontecesse.

### Sem sentido: não havia chão pra duvidar em cima

O §30 congelou três coisas que **nunca** mentem — o relógio, o inventário e a
porta da frente. Está lá, funciona, e o jogador nunca soube: a tabela
`PERCEPCAO_INVIOLAVEL` só era lida por função de depuração.

Sem um chão firme conhecido, duvidar não é jogar — é ruído. *"Nada é
confiável"* não é uma regra, é a ausência de uma. Com três âncoras que o
jogador conhece pelo nome, a dúvida vira trabalho: você tem onde pisar pra
medir o resto.

E as ilusões grandes **se anunciavam**: abriam uma tela com o título "Você tem
certeza?". Alucinação que chega com crachá de alucinação não assusta ninguém.

### O que entrou — `s38-sanidade.js`

**1 · Os sussurros.** 18 ilusões pequenas, 8 delas desenhadas para `min: 0.02`,
que é a faixa do `tenso`. Elas chegam ao jogador por `diz(..., 'narr')` — a
**mesma classe de qualquer outra linha de narração**, de propósito. Não têm
tela, não têm título, não têm confirmação. Chegam ao trocar de cômodo, que é o
batimento natural do jogo dentro de casa, com teto de 5 por dia e 2 turnos de
intervalo.

O número do estágio **não foi inflado**: `tenso` continua valendo 0.08. O que
mudou é que agora existe conteúdo desenhado pra essa faixa.

```
estágio        antes   agora
  lúcido           0       0     (continua correto)
  tenso            0       8     ← a promessa escrita virou verdade
  fissurado       13      26
  rachado         20      38
  desfeito        23      41
```

**2 · As três âncoras chegam ao jogador, e viram verbo.** `CHAO_FIRME` — o
relógio, o inventário e a porta. `ensinarAncoras()` conta pro jogador uma vez
só, depois do segundo sussurro, quando ele já tem motivo pra querer saber.
Depois disso, `conferirAncora()` é um botão no cômodo: custa **10 minutos** do
relógio, devolve **2 pontos** de sanidade e liga `S._verdade` por 1,8s — que é
o intervalo em que a interface para de mentir.

Não cura. O preço é tempo, e o tempo é o recurso que o jogo cobra mais caro.
Conferir é escolher não fazer outra coisa.

*(O nome não é `ANCORAS`: o jogo já tem uma tabela com esse nome e com o
sentido **oposto** — as âncoras afetivas, que são justamente as que se
contaminam. Duas tabelas com o mesmo nome, num escopo global de 1445 nomes, é
uma delas sumir em silêncio.)*

**3 · A sanidade vira sintoma na tela.** Antes ela era o nome de um estágio
numa ficha. Agora `sanIntensidade()` mapeia sanidade 82→15 em 0→1 e um véu
`#san-veu` responde a isso continuamente: grão, vinheta que fecha, pulso que
desacelera, e acima de 0.30 um tremor de 1,4px no texto. O jogador vê a
sanidade cair **antes** de ir olhar o número.

Tem chave de desligar (`S.semSintoma`), porque tremor de tela não é opcional
pra quem precisa que não seja.

**4 · A ilusão fala do seu cômodo.** A ilusão passa a ler onde o jogador está.
"Alguém falou o seu nome em outro cômodo" é uma frase; a mesma frase quando
você sabe que só tem você na casa é outra coisa.

### Regra de ouro

Nada aqui é aleatório de graça. Sussurro só chega em estágio que o jogo já
disse que produz sussurro; a âncora sempre diz a verdade e o jogador sabe
disso; o véu é função contínua da sanidade e de mais nada. Se o jogador for
conferir depois, tudo tem explicação.

### Verificação

`tools/testes/santeste.mjs` — 30 asserções, incluindo a medição do pool vazio
antes e depois. Regressão completa: **506 asserções, 0 falhas, 18 harnesses.**

Um aviso do processo, que ficou anotado no `LEIA-ME` dos testes: as primeiras
rodadas passavam sem provar nada porque estavam sendo feitas **com sanidade
cheia**, onde `lúcido` não produz nada por definição. E `mexerSan(-22)` sozinho
não muda estágio nenhum — `v9().escudo` são 30 pontos que absorvem a primeira
queda inteira.


## v64 — a linha de saldo

### A medição contradisse a suspeita óbvia

A queixa era: *"quase toda hora enquanto eu jogo, é difícil de entender o que
acontece pela forma que é dita."* A suspeita natural é frase comprida. Fui
medir as 851 falas do jogo:

```
mediana ........ 10 palavras
p90 ............ 16 palavras
acima de 28 .... 4 falas (e três delas são o tutorial)
```

As frases são **curtas**. O problema é outro, e é bem maior:

> **239 falas — 28% do total — acontecem coladas a uma mudança de recurso e
> não dizem o número.**

Você lê "A febre cedeu." e não sabe se gastou remédio, quanto, nem quanto
sobrou. Lê "Ele saiu de madrugada sozinho." e não sabe se perdeu uma pessoa.
A frase conta a **cena** e esconde a **conta**.

### O conserto não é reescrever a prosa

Reescrever 851 falas pra encaixar número em cada uma mataria o sentimento — e
o pedido foi explícito: mais fácil de entender **sem tirar** o sentimento.

Então a prosa fica intacta e o jogo mostra o saldo numa linha separada, em
fonte de mostrador, logo abaixo:

> A febre de Marlene cedeu de madrugada.
> `−1 remédio`
>
> Damião chegou no fim da tarde. Trouxe o que tinha nos bolsos.
> `+2 latas · +Damião`

A prosa é o que aconteceu com as pessoas. O saldo é o que aconteceu com a
casa. Duas vozes, dois trabalhos.

**Como ele sabe:** não perguntando a ninguém. Fotografa os recursos e mostra a
diferença quando a foto muda. Isso pega **toda** mudança, inclusive as que
acontecem em código que ninguém lembra que existe — e é por isso que é assim,
e não uma chamada manual em 239 lugares.

**A cor segue o significado, não o sinal.** Ganhar comida é dourado; ganhar
ruído é vermelho, mesmo sendo "+". Perder ruído é dourado, mesmo sendo "−".

**Quem chega e quem morre aparece pelo nome**, não como número.

Mudança pequena demais não vira linha (ruído sobe de 1 em 1 o tempo todo, e
virar linha a cada ponto transformaria o registro em chuvisco — que é o
problema de origem). Dá pra desligar, e a escolha vai pro save.

### O guia, uma ideia por linha

As quatro falas que passam de 28 palavras são quase todas da tela de ajuda,
que empacotava três regras numa frase só. Aqui a reescrita é certa e é a única
do jogo: isto é texto de **instrução**, não de história. A prosa da casa
continua intocada — ela não está explicando nada, está contando.

Média caiu pra **9 palavras por linha**, nenhuma acima de 14.

### Uma trava nova, porque eu me queimei

Troquei acentos por script e a substituição cega não distinguiu o **texto** que
o jogador lê do **identificador** que o código usa:

```
S.ruido          → S.ruído
{k:'remedio'}    → {k:'remédio'}
minimo:{ruido:3} → minimo:{ruído:3}
cena.casa.voce   → cena.casa.você     ← derrubava o Voltar da ajuda
```

JavaScript **aceita** acento em identificador, então nada disso deu erro de
sintaxe: deu erro de comportamento, calado, longe de onde foi escrito. O saldo
simplesmente parou de reportar remédio, água e ruído, e o teste pegou.

Virou trava de build: `montar.js` agora **quebra** se achar acento em nome de
campo ou de variável. Texto acentuado dentro de string continua livre — é lá
que o acento tem de estar.

### Testes

`tools/testes/saldoteste.mjs` — 26 asserções.

476 asserções em 17 harnesses, 0 falhas.

## v63 — cada arma faz uma coisa que só ela faz

### O problema, medido

São 12 armas. Nove delas diferem em `dano` e `kg` — e mais nada. Tirando esses
dois campos, ficam **indistinguíveis**. E o jogo consulta todas por uma função
só:

```js
melhorArma() → a de maior dano
```

Existe **uma** arma útil por vez, e as outras onze são peso. Achar um facão
depois de já ter uma marreta não era achado, era lixo.

### Duas descrições prometiam mecânica que não existia

| item | dizia | fazia |
|---|---|---|
| foice | "Alcance bom e corta o que encostar." | nada além de dano 3 |
| espeto | "Feita em casa. Mantém a coisa longe." | nada além de dano 2,2 |

Promessa escrita e não cumprida é a forma mais barata de mentir pro jogador.
Agora as duas cumprem, e as descrições de todas as nove foram reescritas pra
dizer o que a coisa faz de verdade.

### Os verbos

**A arma serve de ferramenta.** Nove armas cobrem seis ferramentas. Sai do que
a coisa É, não de tabela inventada: machado corta como serrote e cava como pá,
barra faz alavanca, faca tem ponta fina de chave de fenda.

Antes, faltando o serrote, você só tinha "Improvisar com o que tem" — **24% de
dar certo**. Agora tem um conserto de verdade, com preço: uma hora a mais, e a
arma sai pior do que entrou.

E os limites são duros, porque sem limite isso viraria chave-mestra:

- ferramenta sem substituto (a **escada**) continua faltando;
- cobrir só uma das duas ferramentas **não basta**;
- **arma não vira cimento** — faltando material, não há plano.

**A faca vai no cinto.** É a única arma que não ocupa a mão, e mão ocupada
atrapalha tudo que exige mão livre. É por isso que ela vale, com dano 1.

**O taco não quebra.** Madeira maciça, sem fio pra perder. 40 golpes e ele está
igual — enquanto o facão, nos mesmos 40, foi de 100 a 0.

**A foice chega antes.** Alcance vira vantagem na chance de acertar.

**O espeto não mata — te tira de lá.** 82% de sair inteiro, com tudo, sem
barulho. É uma vitória diferente, e às vezes melhor.

### Revólver e espingarda não ganharam verbo, de propósito

`municao` **já é** o verbo delas: são as únicas armas que acabam, e as únicas
que trazem o resto da rua junto (+14 de ruído no tiro dentro de casa). Alto,
finito e definitivo separa mais uma arma das outras do que qualquer coisa que
eu pendurasse por cima. A primeira versão do meu teste não contava isso e
reprovou o desenho por causa da régua — a régua é que estava errada.

### Testes

`tools/testes/itensteste.mjs` — 26 asserções. A primeira delas **mede o
problema**: tira `dano` e `kg` de cada arma e conta quantas sobram idênticas.

450 asserções em 16 harnesses, 0 falhas.

## v62 — mais fôlego nas falas da porta

### Medi antes de reescrever

A queixa era que as frases soam robotizadas. Fui olhar, e o problema não é a
qualidade do que está escrito — é a **quantidade**:

```
antes:  16 perguntas · 38 respostas boas · 45 ruins
depois: 16 perguntas · 86 respostas boas · 77 ruins
```

Com 2 respostas boas por pergunta, você vê a **mesma frase certa** na segunda
vez que faz a mesma pergunta. E resposta certa repetida é pior que errada
repetida, porque a certa é a que você mais ouve: quem sobrevive faz muita
pergunta e abre pouco.

Então nada foi reescrito. Foi **acrescentado**: +3 boas e +2 ruins por
pergunta, no mesmo tom do que já existia. Nenhuma pergunta ficou com menos de
4 de cada.

### O que faz uma resposta errada ser boa

Ela tem de ser explicável **depois**. O jogador erra, abre a porta, e no dia
seguinte consegue dizer em voz alta o que deixou passar. Os moldes que o jogo
já usava e que eu segui: espelho, vago, preciso demais, nega o universal, sabe
da casa, a frase quebra.

O molde novo: **responde outra pergunta.**

> — Encosta a mão na fresta, com a palma pra cima.
> — *Ele põe a mão, e a palma está virada pro chão.*
> ⚠ Você pediu palma pra cima. Ela ouviu o som do pedido, não o pedido.

### O morto que já bateu aqui estourava

`gerarVisitante` tem um ramo raro e bonito — alguém que já bateu na sua porta,
morreu, e volta:

```js
v2.respostas[k]={txt: errado ? sortear(PERG[k].ruim(ant))
                             : sortear(PERG[k].bom(ant)), …}
```

`ruim` é **array**, não função. E `bom` **não existe** — o campo se chama `ok`.
Duas chamadas de função em cima de coisas que não são função.

Sobreviveu tanto tempo porque o ramo só roda com 6% de chance, e só depois que
alguém que já visitou morreu. Quando acontecia, o jogador via a porta
simplesmente não responder.

Provado em teste antes de consertar (`typeof PERG[k].ruim === 'object'`,
`typeof PERG[k].bom === 'undefined'`), e depois: **200 visitantes gerados, 0
estouros**, todos com respostas montadas e as erradas com a explicação junto.

### Testes

`tools/testes/falasteste.mjs` — 18 asserções. Uma delas confere que **toda**
resposta errada explica por que estava errada; outra, que nenhuma fala repete
literalmente dentro da mesma pergunta; outra, que aplicar o bloco duas vezes
não infla a lista.

424 asserções em 17 harnesses, 0 falhas.

## v61 — o ouvido na porta, e o final no dia 30

### "Eu não escuto nada, e mesmo quando escuto não significa nada"

As duas metades da queixa estavam certas, e por motivos diferentes.

**Não escuto nada.** São 12 s de respiração sintetizada, num celular, com o
gerador roncando por baixo. O som existe e é bem feito — mas depender só dele
é apostar o miolo do jogo no alto-falante do aparelho.

Agora o que se ouve também se **vê**: um traço desenhado a partir do *mesmo
perfil* que gera o som. Não é legenda — é o mesmo dado, noutro sentido.

| no som | no traço |
|---|---|
| respiração | onda, com a régua pontilhada de "como é gente" atrás |
| passo | barra com altura de peso — sem peso, vira toco vermelho |
| roupa | o risco ao lado do passo; sem roupa, o risco some |
| engolir, fungar, tossir | pontos no alto; corpo mudo não desenha nenhum |
| ar sem peito atrás | a onda vira linha oca |

**Não significa nada.** Três defeitos de desenho, todos reais:

1. **O original sorteava 3 das 4 camadas pra perguntar.** Medido em 4.000
   sorteios: em **22,6% dos casos** o único defeito do mímico caía justamente
   na camada que ficou de fora — a resposta certa *não existia na tela*. Isso
   não é dificuldade, é armadilha, e é o que a regra de ouro proíbe.
   Agora as quatro camadas aparecem sempre.
2. **Não havia referência.** "Rápida demais" comparada com o quê? Agora existe
   um botão que lembra como é gente respirando, de graça — cobrar por isso
   seria cobrar pra ler a regra do jogo.
3. **Uma escuta só, julgada de memória.** Agora dá pra ouvir de novo quantas
   vezes quiser, a +3 de ruído cada. É decisão, não brinde: quem fica com a
   cara colada na porta ouve o jogo dizer que lá fora sabem disso.

E a ordem dos botões parou de ser sorteada a cada vez. Embaralhar as opções
impedia o jogador de aprender onde as coisas ficam.

### A variação é de tempo, não só de altura

Na primeira versão do traço a variação da respiração só mexia na **altura** do
pico — e no papel "gente de verdade" e "metrônomo" saíram quase idênticos. O
defeito existia no som e não existia no desenho.

Gente nunca repete o mesmo intervalo entre duas respiradas; metrônomo repete
sempre. Agora cada ciclo tem duração própria, e o **espaçamento desigual** é a
primeira coisa que o olho pega.

### O final também acontece no dia 30

A fuga no Opala é uma saída; chegar até o dia 30 é outra. Quem nunca achou o
carro também merece o final — e depois de um mês trancado nessa casa, é o
final que faz sentido: não houve mês nenhum.

`S.viuFinal` é dado puro e vai no save, então fechar o app no meio não faz o
final repetir na próxima abertura.

### Testes

`tools/testes/ouvteste.mjs` — 20 asserções, incluindo a medição dos 22,6% de
respostas impossíveis do desenho antigo.

406 asserções em 16 harnesses, 0 falhas.

## v60 — o final, e a abertura de volta

### O final

`s33-final.js` + `final/`. O jogo tinha fim; não tinha final. `fimOpala`
levava direto pra tela de estatística — você fugia e o jogo te mostrava
números. Entre uma coisa e a outra agora tem a história inteira: a irmã que
sai buscar comida, o mês contando coisas que não aconteceram, as três batidas,
a voz certa demais, a luz — e o hospital.

### Alinhar 274 s de narração sem poder ouvi-los

A narração são 274 s contínuos e eu não escuto áudio. Os tempos das 46 frases
saíram de **medir**: o mp3 foi decodificado no Chromium (Web Audio tem
decodificador de verdade), reduzido a um envelope de RMS a cada 20 ms, e as 46
frases foram encaixadas nas 95 pausas detectadas por **programação dinâmica** —
custo = (tempo previsto pela contagem de letras − tempo da pausa)².

Erro médio de **1,09 s**, máximo 3,12 s. E o erro é o teste: se a hipótese
sobre qual texto foi narrado estivesse errada, ele explodiria.

### A trilha sai da mesma linha do tempo que os quadros

Uma lista só manda na tela e no áudio. Duas listas que pudessem discordar era
o jeito garantido de a voz entrar por cima da narração.

Nada de ganho no olho: cada arquivo foi medido e o alvo é em LUFS.

| arquivo | RMS medido | tratamento |
|---|---|---|
| narração | −21,3 dB | loudnorm −19 |
| gravações de celular | −41,6 a −47,7 dB | passa-alta 95 Hz + redutor de ruído + loudnorm −17 |
| áudio do vídeo | −43,0 dB | loudnorm −23 |

As gravações estavam **20 a 26 dB** abaixo da narração. Subir 26 dB de um mp3
de WhatsApp sobe o chiado junto, por isso o passa-alta e o redutor vêm antes.

Música em **dois movimentos**, com silêncio entre eles: ela sai antes da porta
e volta quando a porta abre. As três batidas precisam cair no silêncio.

### Verificar por medida, já que não dá por escuta

```
cada pedaço no seu lugar ......... 16/16
voz no mesmo peso da narração .... 5/5 (dentro de 5 dB)
clipe ............................ nenhum (pico 0,896)
buraco de silêncio ............... nenhum
```

### A abertura narrada tinha sumido — e a culpa era minha

Você notou. Estava certo, e a causa é do §31.

`orqNovaNoite()` roda na carga da página pra preparar o orçamento da primeira
noite, e chama `marcarSujo()`. O save debounced disparava 1,2 s depois e
**gravava um save antes de o jogador digitar o nome**. Aí `temSave()` dizia que
havia partida, o boot mostrava "Tem uma casa esperando" na **primeira vez que
alguém abria o jogo**, e a abertura nunca tocava.

Nenhum erro. Nenhum aviso. Só a abertura sumindo.

**Não era um bloco: eram onze.** Todo bloco que embrulha `salvar()` escrevia
direto no localStorage com `JSON.parse(localStorage.getItem(CHAVE)||'{}')` — e
esse `||'{}'` é justamente a licença pra criar um save do nada. A regra agora é
uma frase:

> **Bloco ANEXA a um save. Bloco nunca CRIA um save.**

Mais duas guardas: `salvar()` desiste sem `S.nomeJogador`, e `temSave()` trata
save sem nome como lixo e apaga — quem já pegou a versão com o defeito não
fica preso na tela de "Voltar pra lá" com uma casa que nunca existiu.

`tools/testes/aberturateste.mjs` — 14 asserções, e a primeira delas é
"nada é escrito no localStorage antes de a partida começar".

### Dois defeitos que só os quadros renderizados pegaram

- `bloco()` recebia `cor` e **nunca aplicava `fillStyle`**: o texto herdava a
  cor do último gradiente pintado e ficava roxo-escuro sobre roxo-escuro.
- grão e vinheta eram pintados **por último**, ou seja, por cima das letras. A
  narração inteira estava ilegível.

### O caminho do iframe foi removido, não esquecido

A ideia era abrir `final/final.html` num iframe por cima do jogo. Dentro da
página do jogo o iframe **nunca completava a carga** — nenhum erro, nenhum
aviso, nem o evento `load`. Fora do jogo, a mesma página carrega em 1,5 s. Não
achei a causa, e caminho que só funciona no teste é pior que caminho nenhum.

O final dentro do jogo é a mesma cena lida na tela, com os mesmos tempos. O
filme existe à parte, como arquivo de vídeo.

### Três falas sem gravação

Dois pares de arquivos enviados eram **byte a byte idênticos** (mesmo md5).
Faltam "A comida tá acabando…", "Eu também vou." e "Mas…". Elas aparecem
escritas com o tempo respeitado — é só largar o mp3 na pasta e apontar em
`FALAS`.

### Testes

383 asserções em 15 harnesses, 0 falhas.

## v59 — memória cognitiva da casa (Fase 3)

`s32-memoria.js`. A casa passa a lembrar de **como** você joga — e a cobrar
por isso. Nada aqui é conteúdo novo: os três comportamentos são feitos com o
que o jogo já tinha, e o único registro novo (a isca) existe porque o
comportamento pedido precisava de um.

### Média móvel, não contador

Contador é injusto duas vezes: nunca esquece e nunca perdoa. Quem se escondeu
trinta vezes no dia 3 continuaria sendo "o que se esconde" no dia 20. A média
móvel exponencial (α = 0,28, **meia-vida de ~2 noites** medida em teste)
resolve os dois — e o esquecimento **é** a própria média sendo alimentada com
zero nas noites em que o método não apareceu. Não existe um segundo mecanismo
de decaimento pra discordar deste.

### A casa só age com certeza

`memLer` é a **única** porta de leitura e devolve **zero** — não "um pouco" —
enquanto a confiança não passa de 0,6. Confiança é `n/(n+4)`: **seis noites de
evidência** antes de a casa mexer uma palha. Sem isso ela reagiria a
coincidência, e perseguição sem causa é aleatoriedade com outro nome.

| n | 1 | 3 | 6 | 7 |
|---|---|---|---|---|
| confiança | 0,20 | 0,43 | 0,60 | **0,64** |
| lido | 0 | 0 | 0 | **0,90** |

### Os três comportamentos

**1 · Encarece, não elimina.** Método usado sempre torna a contra-anomalia dele
mais provável. O multiplicador é **sempre ≥ 1** e tem teto (1 + 0,70 × 1,4 =
1,98): no máximo dobra o peso de escolha, nunca zera nenhum outro. Testado em
todo o catálogo — mínimo 1,0, máximo 1,961.

A tabela `MEM_CONTRA` tem sete linhas e cada uma aponta pro conteúdo que já
existe: quem resolve com luz acesa fica mais sujeito a `avaria_fiacao` e
`avaria_curto`; quem se esconde, ao Imitador e ao Rastejante; quem corre, ao
Coro. Onde o jogo não tem contra pro método, a linha não existe — inventar uma
seria conteúdo novo disfarçado de balanceamento.

A rotina de cômodo não tem tabela nenhuma: **o cômodo mais pisado é o que
estraga**, lido do `AVARIAS[k].onde` que o jogo já tinha escrito.

**2 · A isca.** Quem resolve tudo com luz acesa nunca precisou do escuro. Com
`metodos.luz > 0,75` e confiança, numa calmaria, a casa apaga uma luminária
perto de você. Tem piscada antes (`tell`), paga orçamento pelo orquestrador
como qualquer evento, deixa cicatriz, e não volta antes de 5 noites.

Calmaria neste jogo **não** é "não há bicho na casa": fora da invasão o jogador
nem anda pela casa. É o bicho **longe** — 3 cômodos ou mais, num casarão de
diâmetro 4 — no meio da noite, sem evento nos últimos 4 turnos e fora do vale.
A primeira versão barrava qualquer coisa no ar e com isso a isca ficou
**inalcançável em jogo real**: o teste passava porque montava o estado à mão.
Comportamento que nenhum caminho real alcança é comportamento morto.

**3 · O ciclo quebrado.** Quatro noites seguidas de invasão ensinam um ritmo.
Na quinta a casa não faz nada:

> Nada bateu na porta.
> **Nenhum susto. Só silêncio.**
> Você fica acordado até de manhã esperando o que não veio.

A noite inteira vira vale, nada pede permissão porque nada é concedido, e não
acontece duas vezes seguidas (cooldown de 8 noites). Só dispara com o ritmo
**aprendido** — quebrar um ritmo que ninguém percebeu é bug com nome bonito.
Uma única noite sem invasão zera a contagem.

### Vazia por decisão ≠ vazia por azar

`orqSimular` passou a separar as duas. Com a memória limpa: 10.000 noites, 0
zeradas, 0 por decisão. Com o ritmo aprendido: 3.000 noites, **4 por decisão, 0
zeradas**. A única noite sem eventos é a que a casa escolheu esvaziar.

### Hostilidade com teto

Sobe quando você ganha a noite (+0,12 por ponto forte), desce quando a casa
acerta, decai 0,06 por noite sozinha, e **para em 0,70**. Por melhor que você
jogue, existe um limite de quanto a casa aperta — jogar bem nunca vira punição
infinita.

### Consolidação sem apagar em silêncio

Balde cheio (16 entradas) não apaga o passado: as mais fracas viram uma só,
`outros`, que carrega a massa delas. A casa deixa de saber **qual** era e
continua sabendo **quanto** era.

### Testes

`tools/testes/memteste.mjs` — 59 asserções, 0 falhas. Inclui a prova de que
**nada no sistema de memória chama `Math.random`** (contador instalado por cima
de `Math.random` durante uma noite inteira simulada: 0 usos), que o estado é
dado puro que sobrevive a JSON ida e volta, e que save legado carrega com a
casa sem saber nada de você — que é o estado correto.

Regressão completa depois do §32: 354 asserções em 11 harnesses, 0 falhas,
varredura ampla com 0 estouros e 0 invariantes violados.

### De quebra: `diasAteTeto` não queria dizer o que dizia

A fumaça no pacote pegou. O comentário do §25 prometia que `dia >= diasAteTeto`
devolve o teto; a conta dividia por `diasAteTeto` e o teto só chegava no **dia
13**. O erro sobreviveu a uma suíte inteira porque a asserção que "provava" a
saturação era:

```js
ok('satura em 0.80', d.t[d.diasAteTeto]===0.80 || d.t[d.diasAteTeto-1+1]===0.80);
```

Os dois lados são o **mesmo índice**. Ela passava sempre e não media nada.

Agora a conta divide por `diasAteTeto-1` e o dia 12 devolve exatamente 0,80 —
nome, comentário e código dizendo a mesma coisa. E o teste passou a conferir
**dois** pontos: que o dia 12 chegou no teto e que o dia 11 ainda não.

| dia | 1 | 5 | 9 | 11 | **12** | 13 | 40 |
|---|---|---|---|---|---|---|---|
| multiplicador | 0,600 | 0,660 | 0,764 | 0,795 | **0,800** | 0,800 | 0,800 |

### Pacote

`v59.zip` — 65 arquivos, 2,8 MB, validado em diretório limpo: descompacta,
`node montar.js` reconstrói o `index.html` sozinho, e o jogo abre e joga a
partir do que saiu do zip (13 asserções de fumaça sobre o pacote, não sobre a
cópia de trabalho).

## v58 — orquestrador de tensão (Fase 2)

`s31-orquestrador.js`. A camada que faltava: até aqui cada sistema sorteava
sozinho, e o jogador vivia a soma de dados independentes — às vezes três
sustos colados, às vezes uma noite morta. Isso **é** aleatoriedade, que é o
que a regra de ouro proíbe. Agora existe **um** lugar que autoriza evento.

### O silêncio é conteúdo

Os vales de silêncio são agendados **antes** de qualquer permissão ser pedida.
Não é o que sobra da noite: é o que foi reservado dela. Dentro do vale nada
passa — nem o primordial. É o único bloqueio absoluto do sistema, porque
silêncio que qualquer prioridade fura deixa de ser silêncio reservado.

Fora de invasão o relógio de turnos não anda, e turno 0 não é vale: a casa
continua podendo estragar de dia. Sem essa porta, uma noite que acabasse
dentro de um vale deixaria a casa congelada até a noite seguinte.

### Critério de aceite — 10.000 noites simuladas

```
[orq] 10000 noites · média 5.91 · min 3 · p50 6 · p90 7 · max 9
[orq] noites zeradas: 0 · estouros de orçamento: 0 · faixa alvo 4–8 · DENTRO
  3 eventos | # 20
  4 eventos | ##### 461
  5 eventos | ############################# 2711
  6 eventos | ############################################## 4293
  7 eventos | ######################## 2227
  8 eventos | ### 282
  9 eventos | # 6
```

`orqHistograma(n, semente)` no console imprime isso a qualquer hora.

### Noite zerada é impossível por construção, não por sorte

No turno 1 de uma noite nova não há cooldown, não há vale (o primeiro começa
no turno 3) e o orçamento está inteiro. O primeiro candidato elegível **sempre**
passa. Um teste de 500 noites confere justamente isso — e foi ele que pegou o
defeito: `orqTentar` desistia do turno inteiro quando o sorteio caía num
candidato de precondição falha. Agora a negativa **do candidato** (precondição,
incompatibilidade) tira ele do pool e o turno segue; só a negativa **do turno**
(vale, cooldown, orçamento) encerra a tentativa.

### A autoridade é real — ninguém fura a fila

| quem | como pede |
|---|---|
| invasão | `checarInvasao` pede permissão pelo bicho sorteado |
| avaria espontânea | `abrirAvaria` pede permissão antes de inserir |
| avaria de cadeia | **não pede** — foi ganha pelo descuido, negá-la apagaria consequência |

A linha 1 do `checarInvasao` original é um segundo sorteio que passaria por
cima da negativa. Ele é silenciado zerando `riscoInvasao` enquanto o original
decide (`chance(0)` é falso sempre). Sem isso o orquestrador não seria
autoridade, seria sugestão.

### Nada se perde, nada se empilha

Evento negado volta ao pool com peso maior (+0,45 por negativa, teto 1,8), uma
entrada por id — não uma por negativa — e some da fila quando é concedido. A
janela de repetição encarece o que acabou de sair (×0,25) sem proibir.

### As cinco faixas de prioridade, agora com conteúdo em todas

A primeira versão de `classeDe` olhava `duracaoTurnos[1]>=20` e classificava
**toda** avaria como persistente: duas das cinco faixas ficavam vazias —
parâmetro morto travestido de design. A faixa agora sai do que a coisa custa ao
jogador, lida dos dados que a `AVARIAS` já tem:

| faixa | prioridade | quantos | regra |
|---|---|---|---|
| primordial | 100 | 1 | o primordial |
| criatura | 80 | 5 | as outras criaturas |
| persistente | 55 | 11 | avaria com `pior` (piora sozinha) ou `efeito` (cobra toda noite) |
| comum | 30 | 2 | avaria terminal de cadeia, mas inerte por noite |
| ambiental | 10 | 2 | avaria que não piora nem cobra: textura |

Preempção só acontece com Δprioridade ≥ 25 (`ORQ_CFG.deltaPreempcao`): trocar
um evento por outro quase igual confunde mais do que ajuda.

**Desvio declarado:** o prompt chamava a faixa mais baixa de "clima ambiental".
O clima e os ruídos ambientes da casa **não** passam pelo orquestrador — o
`RUIDOS_CASA` é desenho de som contínuo, e fazê-lo pedir permissão calaria a
casa. A faixa existe e tem conteúdo (avaria inerte), mas não é o clima.

### Ciclo de vida do que está no ar

`S.anomAtivasLista` agora fecha o ciclo: criatura sai ao fim da invasão (em
`finally`, dê no que der — fuga, morte, amanhecer) e no início de cada noite;
avaria sai quando é reparada e **fica** quando não é, porque ela é a casa
quebrada. Sem isso um id de criatura pendurado barraria as outras cinco pra
sempre — cada uma lista as outras em `incompativelCom`.

### Testes

`tools/testes/orqteste.mjs` — 51 asserções, 0 falhas. Orçamento como teto,
cooldown global e de categoria isolados um do outro, matriz de coexistência
simétrica nos 420 pares, preempção, fila de adiados, vales, as 10.000 noites,
determinismo por semente, estado puro no save, save legado sem orquestrador, e
a autoridade não sendo furada.

## v57 — núcleo de governança (Fase 1)

`s30-nucleo.js`. Contrato, não conteúdo: schema, máquina de estados, RNG
determinístico e âncoras de percepção. **Nenhuma das anomalias existentes foi
reescrita** — elas são envelopadas por adaptadores que apontam pra fonte.

### As quatro decisões que tomei

| pergunta | decisão |
|---|---|
| qual é o conjunto das "33"? | **15 AVARIAS + 6 criaturas = 21 eventos governados.** As 12 de `ANOMALIAS` ficam fora: elas já **são** os tells da porta. 12+15+6=33 é de onde veio o número |
| RNG 100% semeado? | **não.** Semeado no que decide jogo; cosmético (jitter de áudio, grão, oscilação) fica com `Math.random` |
| as 12 entram no schema? | **não** — erro de categoria: precisariam de um tell do tell |
| a invasão vira serializável? | **sim.** Era variável local; fechar o app perdia a noite |

### O que o núcleo entrega

- **`criarRNG(seed)`** — mulberry32. Estado é **um número**, então cabe no save.
  `next`, `inteiro`, `escolher`, `pesado`, `chance`. Semente de `saveId + noite`.
- **`S.debug.replay(seed, acoes)`** — reproduz uma sessão idêntica. Ações são
  dado puro (`{fn, args}`), nunca closure.
- **`validarAnomalia`** — **anomalia sem `tell` é rejeitada**, e a mensagem diz
  "SEM TELL — anomalia sem aviso é bug".
- **`transicionar`** com as 10 fases e validação: transição inválida lança em
  modo dev, registra em produção, e **não muda o estado**.
- **`vigiarEstados`** — teto de turnos por estado. Softlock deixa de depender de
  sorte.
- **`PERCEPCAO_INVIOLAVEL`** congelado: relógio, inventário e porta da frente
  nunca são falsificados. Sem âncora, o jogador conclui que nada é confiável e
  **para de investigar**.
- **`espelharInvasao` / `reidratarInvasao`** — o `I` vira dado puro em `S.inv`.
  Função e nó de DOM são **filtrados na saída**, não confiados ao chamador.

### Os parâmetros mortos da auditoria, agora implementados

| era | virou |
|---|---|
| `I.divididas` (Coro) — escrito 2×, lido 0× | as metades **realmente** param de convergir enquanto divididas |
| `I.recuo` (Magro) — escrito 2×, lido 0× | ele **anda pra longe** de você enquanto recua |
| `BICHOS.raro` — declarado, nunca lido | o campo manda; `estreia` também. O id deixou de estar cravado |
| chamado do imitador duplicado | o do jogo base fica calado enquanto o mecânico fala |

### O achado que me fez mudar o design do Magro

Ao testar `I.recuo` descobri que **a casa começa com todas as luminárias
acesas**. O filtro "não entra em cômodo aceso" esvaziava as opções toda vez e
`moverMonstro` devolvia a posição atual: **o Magro nunca andava.** Inerte no jogo
normal — o mesmo defeito do imitador e do rastejante, e eu tinha subestimado como
"exploit de borda" na auditoria.

Luz agora **deter, não paralisa**: ele prefere o escuro e paga um turno pra
atravessar o aceso, com aviso na tela. O contra-jogo fica melhor — atrasar é
diferente de congelar, e congelar é o que dava exploit.

### E uma contradição minha que o teste pegou

`resolvida` tinha teto finito **e** era isenta do vigia. Ou tem teto e o vigia
age, ou é terminal. `resolvida` é descanso, não fim: agora volta pra `dormente`,
senão a anomalia nunca mais dispara. Só `cicatriz` é terminal.

### Testes

`nucleoteste`: **50 verificações, 0 falhas**. Regressão: `anomteste`,
`rumoteste`, `progteste`, `difteste`, `fugateste`, `v50` — 0 falhas. `varre`: 0
estouros, 0 invariantes violados.

### Ainda não feito

Fase 2 (orquestrador de tensão) e Fase 3 (memória cognitiva da casa).

---

## v56 — marcos e o Opala

`s29-rumo.js`, com `RUMO_CFG`. Duas coisas que se cruzam de propósito.

### Marcos: o mundo muda a cada 4 dias

O jogo **já tinha** uma "virada do meio" (`VIRADAS`, index.html:2039) que dispara
uma vez entre os dias 6 e 7. Não dupliquei: generalizei. Os marcos são periódicos
e reusam as mesmas três forças.

| marco | sinal para o jogador | efeito |
|---|---|---|
| A cidade esvaziou mais | *"O rádio não pega mais ninguém no dial de sempre."* | −7% de rendimento no saque, teto −28% |
| Elas ficaram mais ousadas | *"Bateram antes de escurecer."* + rugido | +5% no risco de invasão, teto +20% |
| Chegou alguém | o evento é o sinal | 55% alguém entra no abrigo; 45% um grupo passa e repara na casa |

Primeiro marco no dia 5, no máximo 5 por partida, e os três tipos aparecem antes
de qualquer um repetir.

**Marco não é o multiplicador do §25.** O marco **soma** no risco; o §25
**multiplica**. Eixos separados, e o teste prova medindo a diferença.

### O objetivo final: o Opala

**Antes de escolher: já existia um.** `telaResgate()` no dia 12 — o caminhão do
Exército, com quatro finais. Não joguei fora; seria destruir um final que
funciona por engano de leitura.

O Opala é um **segundo caminho**, e ele existe porque o primeiro tem um problema:
o caminhão **acontece com você**. Você não faz nada pra merecê-lo. O Opala só sai
se você construir.

| exigência | como se cumpre |
|---|---|
| 2 peças de motor | **só aparecem em oficina e comércio** — expedição específica |
| 55 de diesel guardado | acúmulo, competindo com o gerador |
| 4 noites depois de descobrir | o motor precisa de tempo parado |

**Descoberto no jogo, não anunciado:** você entra no quintal e levanta a lona — e
só repara que dá pra mexer nele se tiver oficina. **Checklist rastreável:** a
entrada "O Opala" aparece no quintal e diz o que falta, item a item. **Final
próprio:** cena `saida`, desenhada por função — a estrada fugindo, as faixas
passando, e a casa encolhendo no retrovisor com a luz ainda acesa.

Narrativamente distinto dos dois lados: no caminhão alguém te salva; no Opala
você sai por conta, e a cidade fica com o que você deixou.

### A prova de que o objetivo continua alcançável

Com **200 marcos de cada tipo** (muito além do teto de 5):

1. rendimento do saque para em **0,72** — nunca chega a zero
2. os dois locais que têm a peça **continuam existindo**
3. risco de invasão no pior caso possível: **0,88** — nunca chega a 1, sempre dá
   pra passar a noite
4. o diesel exigido (55) cabe no máximo que o tanque guarda (100)
5. as noites exigidas passam sozinhas com o tempo

### Três defeitos que os testes acharam

1. **`industrial` não existe.** Eu escrevi que a peça apareceria em "oficina e
   industrial"; os tipos de casa deste jogo são `simples, abandonada, boa, sitio,
   comercio, oficina, tocada`. A peça estava indo pra **uma fonte só**, e a
   promessa de "expedições específicas" ficava vazia. Corrigido pra oficina e
   comércio.
2. **Uma asserção varria scrollback compartilhado.** O teste do final procurava a
   *ausência* da palavra "morreu" em `#texto` — e ela estava lá, escrita por
   outro teste no mesmo buffer. Trocada por afirmar a identidade do final.
3. **`RUMO_CFG` referenciado fora da página** no próprio teste.

### Testes

`rumoteste`: **30 verificações, 0 falhas**. Regressão: `progteste`, `portateste`,
`anomteste`, `difteste`, `fugateste`, `expteste`, `v50`, `qual`, `baktest` — 0
falhas. `varre`: 0 estouros, 0 invariantes violados.

---

## v55 — experiência por uso

`s28-progresso.js`, com `PROG_CFG`. Nada de XP por abate.

| atributo | sobe ao | quanto |
|---|---|---|
| Velocidade | correr | 9 por cômodo **novo** na invasão |
| Força | carregar peso | 0,55 por (kg−6) × hora |
| Destreza | consertar | 26 por reparo |
| Furtividade | escapar sem ser visto | 60 por fuga limpa |

**Usa `S.ficha.pontos` e `parcelas()` do §19.** Não existe objeto novo de
atributo nem contador paralelo — `S.prog` guarda **só o progresso parcial** rumo
ao próximo ponto; quando fecha, o ponto entra em `S.ficha.pontos`, o mesmo lugar
de sempre.

### A curva desacelera

`custo(n) = 100 × n^1,55`. Do 1º ao 8º ponto: **100 → 293 → 549 → 857 → 1212 →
1607 → 2041 → 2511**. O salto também cresce, não só o custo.

### Os quatro anti-exploits, um por atributo

| exploit | proteção | medido |
|---|---|---|
| correr em círculo | só conta cômodo **novo** na invasão | 40 idas e vindas entre 2 cômodos = 18 de XP (os 2 primeiros), não 360 |
| largar/pegar o mesmo objeto | o crédito é por **hora**, e hora só passa em `gastarHoras` | 60 ciclos = **0** |
| consertar/quebrar o mesmo item | um item conta **uma vez por dia** | 30 reparos da mesma faca = 26, o de um |
| re-disparar a mesma fuga | uma vez por fuga, e só com `avisos === 0` | 20 disparos = 60, o de uma. Fuga com detecção = 0 |

Mais um teto diário de 140 por atributo, pra sessão longa não virar corrida de
paciência.

### O teto de 10, provado em quatro caminhos

Doação gigante de uma vez, ganho ao longo de 400 dias, quem já está em 10, e o
caso de o **efetivo** estar em 10 por roupa enquanto o **investido** está baixo —
nesse ainda faz sentido treinar, porque tirar a roupa não pode derrubar o que
você treinou.

### Duas correções ao pedido, ditas em vez de fingidas

1. **A barra de progresso é DOM, não canvas.** Foi pedida "desenhada por função
   no canvas". A ficha deste jogo **não é canvas**: `telaFicha` monta um `<div
   id="ficha">` com innerHTML (§19:476). Desenhar em canvas exigiria uma segunda
   tela de ficha só pra barra — mais código, duas telas pra manter, zero ganho.
   A barra fica onde o número do atributo já está. (O §19 ganhou um `data-atr`
   por atributo, que é a âncora — a lista era string montada, sem elemento por
   atributo.)
2. **O teste do teto de 10 estava errado, não o código.** A primeira versão
   esperava que uma doação gigante de uma vez chegasse a 10; o teto **diário**
   morde antes, e está certo — uma doação gigante não pode furar o limite do dia.
   O teste agora prova as duas coisas separadamente.

### Um teste que era sorteio

`portateste` exigia `custo > 0` na medição de desempenho da silhueta. O efeito é
~0,04 ms e o ruído da bancada é ~0,5 ms: afirmar o **sinal** de algo 25× menor
que o ruído não é teste. Agora ele mede o ruído (diferença entre duas leituras da
mesma condição) e afirma o que dá pra afirmar: **o custo é menor que o ruído**.

### Migração

Save antigo não tem `prog`. O valor neutro é **zero progresso parcial**: não zera
atributo nenhum (o que foi investido na criação continua em `S.ficha.pontos`) e
não presenteia com XP por um passado que ninguém mediu.

### Testes

`progteste`: **28 verificações, 0 falhas**. Regressão: `portateste`, `anomteste`,
`difteste`, `v50`, `qual` — 0 falhas.

### Ainda não feito deste prompt

Partes 2 (objetivo final) e 3 (marcos intermediários). O objetivo final **já
existe** — `telaResgate()` no dia 12, o caminhão do Exército, com quatro finais.
Aprofundar isso é trabalho separado e não foi começado.

---

## v54 — a silhueta debaixo da porta

`s27-porta.js`, com `PORTA_CFG`.

### A tensão de design, dita em voz alta

Foi pedido que cada anomalia fosse **"reconhecível de relance"**. Ao pé da letra,
isso **mata o jogo**: a dúvida na porta é o coração dele, e se dá pra identificar
a coisa num relance não existe dilema — é só olhar e decidir.

O que fiz no lugar: a sombra dá **categoria, não identidade**. Você vê que tem
coisa alta demais, ou baixa e comprida, ou larga demais pro vão, ou mais de uma.
É o bastante pra desconfiar e escolher olhar; não é o bastante pra ter certeza.

**Quinze criaturas caem em seis formas**, e compartilhar é de propósito.

| forma | criaturas | como se lê |
|---|---|---|
| gente | vizinho, mae, casca, fome | duas manchas de sapato |
| alto demais | alto, magro, dobra | manchas estreitas, sombra longa no chão |
| baixo e comprido | rastejo, raiz | a fresta some quase inteira |
| largo demais | inchado, batedor | vai de um batente ao outro |
| mais de um | matilhaC, crianca | mais pés do que cabe numa pessoa |
| não dá pra dizer | fundo, aquilo | não fecha formato nenhum |

### O que não foi mexido

O olho mágico **já tinha** revelação progressiva por zonas, e as 15 criaturas
**já tinham** defeitos próprios (`DEFEITO_CRIATURA`). Isso funciona e ficou como
estava. O que faltava era a sombra debaixo da porta — a primeira coisa que você
vê, antes de decidir se vale gastar o olho mágico — que era retângulo preto igual
pra todo mundo.

### Ritmo de batida por forma

Largo bate forte e devagar (`0s 0.9s`, força 1.5); rastejo bate fraco e miúdo
(`0s .16s .30s .52s`, força .55); "errado" bate fora de qualquer tempo
(`0s .31s .37s 1.1s`). Seis compassos, nenhum repetido.

### Escala relativa, verificada

Medido em **320, 390, 540, 768 e 1080 px**: nenhuma forma sai do canvas e nenhuma
escapa do enquadramento da porta, nem no pior caso do balanço.

### Galeria

    portaGaleria()          as seis formas lado a lado, no canvas do jogo
    portaMostrar('inchado') põe aquela criatura na porta agora

A galeria é **no canvas do jogo**, não numa página separada — página separada
teria de copiar a tabela `FORMA`, e cópia diverge do original no primeiro ajuste.

### Dois defeitos que os testes acharam

1. **Eu chutei a geometria da porta.** A primeira versão usava `w*.52` e `h*.12`;
   os valores reais são `Math.min(w*.60,h*.52)` e `h*.055`, com `chao=h*.90`. A
   mancha saía deslocada. Agora está copiada linha por linha do original, com o
   endereço no comentário.
2. **A medição de custo deu número negativo** (−0,8 ms: desenhar com a sombra
   "mais rápido" que sem). Era aquecimento de JIT. Com aquecimento e medindo nas
   duas ordens: **0,024 ms**, dentro do próprio ruído das amostras — o que é uma
   afirmação mais forte que "menos de 1 ms".

**Isto é proxy, não medição em celular.** Não há instrumentação de quadro no
projeto e eu meço em Chromium headless num servidor.

### Testes

`portateste`: **17 verificações, 0 falhas**. Regressão: `anomteste`, `difteste`,
`fugateste`, `v50` — 0 falhas. `varre`: 184 cliques, 0 estouros.

---

## v53 — as anomalias viram a ameaça

`s26-anomalias.js`, com `ANOM_CFG`. A dificuldade vem do §25 — este bloco
**não cria multiplicador próprio**, como foi pedido.

### O que existia

Seis criaturas com nome, aparência e uma frase de fraqueza — e **uma perseguição
só para todas**: `moverMonstro` andava pro vizinho mais perto de `I.ruidoEm`
enquanto `I.memoria > 0`, senão sorteava. `vel` e `mem` só mudavam números dentro
dessa mesma regra, e o campo `fraco` era **texto exibido, nunca regra**.

### Ciclo de estado explícito

```
RONDA → SUSPEITA → CACA → PERDEU → (volta a RONDA)
```

`PERDEU` é fase de verdade: ela vasculha **em volta** do último lugar conhecido
antes de desistir. Há teto de turnos em `CACA` — nenhuma perseguição é eterna — e
`cooldown` depois de desistir, que é a janela de respiro do jogador.

### Regra única por criatura, com contra-jogo descobrível

| criatura | reage a | contra-jogo |
|---|---|---|
| o Magro | **luz** | não entra em cômodo aceso; a lanterna o afasta |
| o que Rasteja | **rastro** | ignora barulho, segue por onde você pisou |
| Muitas Bocas | **som** | barulho alto separa as duas metades |
| o que Chama | **resposta** | sem resposta vai pro barulho; responder entrega sua posição exata |
| o Inchado | **passagem** | perde turno em cômodo apertado |
| aquilo | **olhar** | olhar direto o aproxima e custa sanidade |

A dica de cada uma aparece em **"Escutar onde ele está"** — descoberta jogando,
sem wiki.

### Aviso antes do dano, garantido

Um turno antes de encostar, a criatura é **obrigada** a emitir sinal, com texto
próprio por criatura. `ANOM_CFG.distanciaAviso` nunca pode ser zero.

### Presença fora do combate

Cada criatura deixa uma marca diferente na casa, e a marca **ainda está lá dias
depois** — aparece ao entrar no cômodo, com quanto tempo faz. Teto de 6 marcas.

### Dois bugs que o teste de 2000 turnos achou — e que teriam passado

O teste roda cada criatura por 2000 turnos e acusa se alguma passa 200 turnos
seguidos na mesma fase. Ele pegou **duas criaturas completamente inertes**:

1. **O imitador ficava preso em RONDA pra sempre.** A primeira versão fazia ele
   ignorar ruído enquanto `respondeu` fosse falso — e nada no jogo jamais setava
   esse campo. Corrigido: ele ouve como as outras, e o que a resposta muda é a
   **precisão** (barulho vs. sua posição exata). O chamado também virou mecânica
   de verdade: antes era só texto de clima dentro de `turnoMonstro`, sem marcar
   nada.
2. **O rastejante ficava preso em RONDA pela mesma razão estrutural.** Ele recusa
   som (certo) e não tinha nenhuma outra porta de entrada (errado). Ganhou
   `anomPisou()`: quem lê o chão acorda quando você anda, não quando você faz
   barulho.

Uma criatura que nunca sai de ronda é uma criatura que não existe. As duas teriam
sido publicadas inofensivas.

### Debug

    anomInvocar('coro')    começa uma invasão com aquela criatura
    anomEstado(I)          fase, turnos, trilha, cooldown, marcas

### Testes

`anomteste`: **28 verificações, 0 falhas**. Regressão: `difteste`, `fugateste`,
`expteste`, `v50`, `qual` — 0 falhas. `varre`: 205 cliques, 0 estouros.

---

## v52 — curva de dificuldade

Multiplicador **único e centralizado** em `s25-dificuldade.js`, com `DIF_CFG`.

    dia 1 → 0.60     sobe (smoothstep, 12 dias)     satura → 0.80

Nunca volta a 1.00, nunca passa de 0.80. A redução permanente de 20% é o teto;
os 40% do dia 1 são a rampa.

### Cinco pontos de aplicação, um embrulho cada

| função | o que controla | modo |
|---|---|---|
| `riscoInvasao` | frequência das anomalias | direto |
| `escassez` | escassez de recursos | direto |
| `pegarMal` | dano recebido (duração do mal) | direto |
| `gastoComida` | custo de fome | direto |
| `folegoPorta` | agressividade suportada | **inverso** |

**Por que `folegoPorta` é inverso:** ele diz quantos encontros você aguenta numa
invasão. Multiplicar por 0.60 ali teria deixado o jogo **mais difícil**, não
menos. Existe `difInverso()` separado, com nome diferente, pra ninguém aplicar o
errado por distração.

### Prova de que não há dupla aplicação

O teste instrumenta `dif()` e conta quantas vezes ela é chamada por invocação de
cada função embrulhada. **Todas devolvem exatamente 1.** Além disso
`embrulharUmaVez()` recusa um segundo embrulho e avisa no console — o teste
tenta embrulhar `escassez` de novo e prova que o valor não muda.

### Uma coisa que foi pedida e NÃO existe neste jogo

**"Tempo de reação exigido em eventos".** Não há nenhuma decisão com prazo: o
jogo é de menu e espera indefinidamente pelo toque. A varredura achou um único
`setTimeout` resolvendo promessa, e é o vigia anti-travamento. A tela do resgate
diz "você tem uns quarenta segundos pra decidir", mas é texto — não há contagem.
Está declarado em vez de fingido. Se um dia existir decisão com prazo, ela usa
`difInverso()` e nada mais precisa mudar.

### Um defeito que o teste achou

`dificuldadeNoDia(1e9)` saturava em 0.80 mas `dificuldadeNoDia(Infinity)` caía
em 0.60 — duas respostas opostas para "número absurdo". A regra virou explícita:
**não-número é save corrompido e cai no dia 1** (o mais fácil: diante de estado
quebrado o benefício é do jogador); **número válido, ainda que absurdo, satura**.

### Save

Nada a migrar. A dificuldade é função pura de `S.dia`, que todo save já tem.
Quem estava no dia 7 entra na curva no ponto do dia 7 — nem punido nem
presenteado. Guardar o multiplicador no save criaria um segundo lugar onde a
verdade mora, e um save velho ficaria preso numa curva antiga pra sempre.

### Debug

    difDia(20)     pula pro dia 20 e mostra o multiplicador na tela
    difTabela()    imprime a curva inteira
    difEstado()    dia, valor, inverso, config e os cinco pontos

### Testes

`difteste`: **24 verificações, 0 falhas**. Regressão: `fugateste`, `expteste`,
`v50`, `qual` — 0 falhas.

---

## v51 — auditoria, expedição transacional e fuga jogável

Quatro fases, quatro commits. O resumo do que quebrou, por que quebrou e o que
mudou.

---

### O que quebrou, e por quê

**O jogador saía pra rua, achava coisas, e voltava pra casa sem nada — com uma
tela dizendo "O jogo travou aqui".**

A causa não era o que parecia. Não era exceção no código de coleta, não era save
sobrescrito, não era sprite faltando (este jogo não usa sprite nenhum). Era uma
**colisão de nome global**.

O jogo é distribuído como um HTML só, e `montar.js` injeta 14 blocos `.js` dentro
dele. Todos compartilham **um escopo global único**: 1 200 nomes de topo num
espaço só. Quando dois blocos escolhem o mesmo nome sem saber um do outro, o
segundo apaga o primeiro — **sem erro nenhum na carga**.

Foi o que aconteceu duas vezes:

| nome | o que era | o que passou a ser |
|---|---|---|
| `capacidade` | quantos **quilos** você carrega na expedição, recebe o **parceiro** | quantos **slots** um baú tem, recebe o **id do baú** (§16) |
| `ficha` | desenha uma **linha de tela** `(nome, tag, texto)` | devolve a **ficha de personagem** `()` (§19) |

A primeira colisão fazia `etapaCarga` chamar `BAUS[parceiro].slots` na sua
primeira linha — antes até de `limpar()`. Por isso a tela nem trocava: o jogador
ficava olhando o texto do saque com a barra de ações vazia, até o vigia disparar
14 segundos depois. E como o saque só era creditado no **fim** de `recolher()`,
voltar pra casa pelo botão do vigia significava perder tudo.

Medido: **28 estouros em 63 expedições**. Praticamente toda saída pra rua que
chegava na tela de carga.

A segunda colisão era silenciosa de outro jeito: 20 e tantas listas do jogo
— gente no abrigo, itens do saque, bancada de armas — simplesmente **pararam de
desenhar**.

Nenhuma das duas apareceu em teste nenhum durante versões inteiras, porque
nenhuma produz erro.

---

### O que mudou

#### Fase 0 — auditoria (`docs/AUDITORIA.md`)
Mapa da arquitetura, da máquina de estados, dos nove depósitos de inventário,
dos pontos de save, dos teleportes e dos acoplamentos indevidos. Nenhuma linha de
código alterada. Veredito das seis hipóteses do briefing: **H2 confirmada**, H1
confirmada em parte, H3/H4/H5/H6 descartadas como causa.

#### Fase 1 — a expedição parou de comer o saque
- `s16`: `capacidade` → **`capacidadeBau`**
- `s19`: `ficha()` → **`fichaJogador()`**
- **`montar.js` quebra o build** se um nome novo colidir. As cinco substituições
  deliberadas estão declaradas em `COLISAO_OK`, cada uma com o motivo escrito.
- **`s23-expedicao.js`** (novo): o saque virou transacional. O `levar` deixou de
  ser variável local e passou a ser `S.exped.levar`, **dentro do estado salvo**.
  Mesma referência de objeto, então a fuga que corta 40% e o susto que corta pela
  metade continuam funcionando sem uma linha alterada.
  - cada pegada marca o save: o que está na sua mão está no disco
  - travou no meio? na próxima abertura o saque volta com você
  - `socorro()` deixou de descartar trabalho: credita antes de levar pra casa
  - achado sem nome, sem quantidade ou com peso `NaN` é registrado e ignorado
  - erro parou de ser engolido: console com contexto + anel de 20 em `S.erros`

#### Fase 2 — varredura (`docs/BUGS.md`)
755 cliques aleatórios em 5 sementes, com toda função global embrulhada num
`try/catch` que denuncia quem estoura, e invariantes checados a cada 20 cliques.
Depois da Fase 1: **0 estouros, 0 invariantes violados, 0 travamentos**.
- **Backup do save**: eram 7 gravações por save, uma por bloco, sem nenhuma cópia
  de segurança. Agora o conteúdo anterior vai pra uma chave de sombra antes da
  primeira gravação (uma escrita por save, não sete), e a carga cai pro backup se
  o principal estiver ilegível.

#### Fase 3 — fugir deixou de ser derrota
`mover()` terminava com `if(PLANTA[dest].saida) return escapou(I)`, e `escapou()`
terminava em `fim('fuga')`. **Andar pro quintal durante uma invasão acabava a
partida.**

**`s24-fuga.js`** (novo) transforma isso num estado com fases legíveis:

```
INVADINDO → VASCULHANDO → SAINDO → SEGURO → RESET
```

- **Quintal e rua são áreas jogáveis**, cada uma com ações próprias: esperar e
  escutar, se enfiar mais fundo no esconderijo, trocar de área, espiar a casa por
  uma fresta, entrar.
- **A regra que faz isso ser jogo:** se ela sai **pelos fundos**, o quintal fica
  perigoso; se sai **pela frente**, a rua. Você ouve pra onde ela está indo e
  escolhe onde esperar.
- **A casa é desenhada de fora**, e a janela do cômodo em que ela está acende com
  a silhueta atravessando. É o "observar a silhueta se movendo" pela via que este
  projeto tem — não há mundo 3D aqui.
- **Nunca machuca sem avisar:** o primeiro erro é susto ("ela cheira o ar, você
  não respira, ela segue"). Só o segundo cobra, e mesmo assim fere e empurra pro
  outro lado — não mata.
- **Consequências em vez de derrota:** ela leva comida, diesel, remédio ou item
  da mochila; arrebenta muro, calha, tábua ou armadilha; acha quem ficou
  escondido. Ficar muito tempo fora custa sanidade, e a volta custa comida.
- **`FUGA_CFG`** concentra todo tempo, chance e custo, cada um comentado. Nenhum
  número solto no meio da lógica.

#### Fase 4 — testes
| suíte | verificações |
|---|---|
| `expteste` — expedição transacional | 19, 0 falhas |
| `fugateste` — ciclo da invasão e fuga | 30, 0 falhas (estável em 3 voltas) |
| `baktest` — backup do save | 6, 0 falhas |
| `varre` — varredura ampla | 0 estouros, 0 invariantes violados |
| regressão: `v50`, `v49`, `qual`, `equipteste`, `menuteste`, `corte`, `gerteste`, `am` | 0 falhas |

---

### Migração de save

Os campos novos (`exped`, `erros`, `fuga`) **não existem** num save antigo, e a
ausência já é o estado correto: ninguém estava no meio de uma expedição nem do
lado de fora de casa. Nada a converter, nada quebra.

---

### Mudanças que quebram compatibilidade de API

Se você tinha código ou teste chamando estes nomes, precisa atualizar:

| antes | agora |
|---|---|
| `capacidade(idDoBau)` | `capacidadeBau(idDoBau)` |
| `ficha()` (ficha de personagem) | `fichaJogador()` |

`capacidade(parceiro)` e `ficha(nome, tag, texto)` voltaram ao significado
original.

---

### O que ficou aberto

- **`cena.modo` é sobrecarregado.** `'vazio'` significa ao mesmo tempo "estou num
  cômodo" e "estou numa cena de corte". 28 pontos de escrita. Já causou três bugs
  distintos. Separar em `modo` + `jogavel` mexe em 28 lugares e o risco é maior
  que o ganho nesta rodada.
- **`sustoAntigo()` é código morto** (`index.html:10172`, começa com
  `if(true)return false`).
- **Não medido:** FPS e memória em sessão longa, outros navegadores, e se alguma
  colisão existe dentro de objetos (`X.metodo = ...`) — a trava só pega
  declarações de topo.
