# CHANGELOG

## v56 — marcos e o Opala

`s29-rumo.js`, com `RUMO_CFG`. Duas coisas que se cruzam de propósito.

### Marcos: o mundo muda a cada 4 dias

O jogo **já tinha** uma "virada do meio" (`VIRADAS`, index.html:2039) que dispara
uma vez entre os dias 6 e 7. Não dupliquei: generalizei. Os marcos são periódicos
e reusam as mesmas três forças.

| marco | sinal para o jogador | efeito |
|---|---|---|
| A cidade esvaziou mais | *"O rádio não pega mais ninguém no dial de sempre."* | −7% de rendimento no saque, teto −28% |
| Elas ficaram mais ousadas | *"Bateram antes de escurecer."* + rugido | +5% no risco de invasão, teto +20% |
| Chegou alguém | o evento é o sinal | 55% alguém entra no abrigo; 45% um grupo passa e repara na casa |

Primeiro marco no dia 5, no máximo 5 por partida, e os três tipos aparecem antes
de qualquer um repetir.

**Marco não é o multiplicador do §25.** O marco **soma** no risco; o §25
**multiplica**. Eixos separados, e o teste prova medindo a diferença.

### O objetivo final: o Opala

**Antes de escolher: já existia um.** `telaResgate()` no dia 12 — o caminhão do
Exército, com quatro finais. Não joguei fora; seria destruir um final que
funciona por engano de leitura.

O Opala é um **segundo caminho**, e ele existe porque o primeiro tem um problema:
o caminhão **acontece com você**. Você não faz nada pra merecê-lo. O Opala só sai
se você construir.

| exigência | como se cumpre |
|---|---|
| 2 peças de motor | **só aparecem em oficina e comércio** — expedição específica |
| 55 de diesel guardado | acúmulo, competindo com o gerador |
| 4 noites depois de descobrir | o motor precisa de tempo parado |

**Descoberto no jogo, não anunciado:** você entra no quintal e levanta a lona — e
só repara que dá pra mexer nele se tiver oficina. **Checklist rastreável:** a
entrada "O Opala" aparece no quintal e diz o que falta, item a item. **Final
próprio:** cena `saida`, desenhada por função — a estrada fugindo, as faixas
passando, e a casa encolhendo no retrovisor com a luz ainda acesa.

Narrativamente distinto dos dois lados: no caminhão alguém te salva; no Opala
você sai por conta, e a cidade fica com o que você deixou.

### A prova de que o objetivo continua alcançável

Com **200 marcos de cada tipo** (muito além do teto de 5):

1. rendimento do saque para em **0,72** — nunca chega a zero
2. os dois locais que têm a peça **continuam existindo**
3. risco de invasão no pior caso possível: **0,88** — nunca chega a 1, sempre dá
   pra passar a noite
4. o diesel exigido (55) cabe no máximo que o tanque guarda (100)
5. as noites exigidas passam sozinhas com o tempo

### Três defeitos que os testes acharam

1. **`industrial` não existe.** Eu escrevi que a peça apareceria em "oficina e
   industrial"; os tipos de casa deste jogo são `simples, abandonada, boa, sitio,
   comercio, oficina, tocada`. A peça estava indo pra **uma fonte só**, e a
   promessa de "expedições específicas" ficava vazia. Corrigido pra oficina e
   comércio.
2. **Uma asserção varria scrollback compartilhado.** O teste do final procurava a
   *ausência* da palavra "morreu" em `#texto` — e ela estava lá, escrita por
   outro teste no mesmo buffer. Trocada por afirmar a identidade do final.
3. **`RUMO_CFG` referenciado fora da página** no próprio teste.

### Testes

`rumoteste`: **30 verificações, 0 falhas**. Regressão: `progteste`, `portateste`,
`anomteste`, `difteste`, `fugateste`, `expteste`, `v50`, `qual`, `baktest` — 0
falhas. `varre`: 0 estouros, 0 invariantes violados.

---

## v55 — experiência por uso

`s28-progresso.js`, com `PROG_CFG`. Nada de XP por abate.

| atributo | sobe ao | quanto |
|---|---|---|
| Velocidade | correr | 9 por cômodo **novo** na invasão |
| Força | carregar peso | 0,55 por (kg−6) × hora |
| Destreza | consertar | 26 por reparo |
| Furtividade | escapar sem ser visto | 60 por fuga limpa |

**Usa `S.ficha.pontos` e `parcelas()` do §19.** Não existe objeto novo de
atributo nem contador paralelo — `S.prog` guarda **só o progresso parcial** rumo
ao próximo ponto; quando fecha, o ponto entra em `S.ficha.pontos`, o mesmo lugar
de sempre.

### A curva desacelera

`custo(n) = 100 × n^1,55`. Do 1º ao 8º ponto: **100 → 293 → 549 → 857 → 1212 →
1607 → 2041 → 2511**. O salto também cresce, não só o custo.

### Os quatro anti-exploits, um por atributo

| exploit | proteção | medido |
|---|---|---|
| correr em círculo | só conta cômodo **novo** na invasão | 40 idas e vindas entre 2 cômodos = 18 de XP (os 2 primeiros), não 360 |
| largar/pegar o mesmo objeto | o crédito é por **hora**, e hora só passa em `gastarHoras` | 60 ciclos = **0** |
| consertar/quebrar o mesmo item | um item conta **uma vez por dia** | 30 reparos da mesma faca = 26, o de um |
| re-disparar a mesma fuga | uma vez por fuga, e só com `avisos === 0` | 20 disparos = 60, o de uma. Fuga com detecção = 0 |

Mais um teto diário de 140 por atributo, pra sessão longa não virar corrida de
paciência.

### O teto de 10, provado em quatro caminhos

Doação gigante de uma vez, ganho ao longo de 400 dias, quem já está em 10, e o
caso de o **efetivo** estar em 10 por roupa enquanto o **investido** está baixo —
nesse ainda faz sentido treinar, porque tirar a roupa não pode derrubar o que
você treinou.

### Duas correções ao pedido, ditas em vez de fingidas

1. **A barra de progresso é DOM, não canvas.** Foi pedida "desenhada por função
   no canvas". A ficha deste jogo **não é canvas**: `telaFicha` monta um `<div
   id="ficha">` com innerHTML (§19:476). Desenhar em canvas exigiria uma segunda
   tela de ficha só pra barra — mais código, duas telas pra manter, zero ganho.
   A barra fica onde o número do atributo já está. (O §19 ganhou um `data-atr`
   por atributo, que é a âncora — a lista era string montada, sem elemento por
   atributo.)
2. **O teste do teto de 10 estava errado, não o código.** A primeira versão
   esperava que uma doação gigante de uma vez chegasse a 10; o teto **diário**
   morde antes, e está certo — uma doação gigante não pode furar o limite do dia.
   O teste agora prova as duas coisas separadamente.

### Um teste que era sorteio

`portateste` exigia `custo > 0` na medição de desempenho da silhueta. O efeito é
~0,04 ms e o ruído da bancada é ~0,5 ms: afirmar o **sinal** de algo 25× menor
que o ruído não é teste. Agora ele mede o ruído (diferença entre duas leituras da
mesma condição) e afirma o que dá pra afirmar: **o custo é menor que o ruído**.

### Migração

Save antigo não tem `prog`. O valor neutro é **zero progresso parcial**: não zera
atributo nenhum (o que foi investido na criação continua em `S.ficha.pontos`) e
não presenteia com XP por um passado que ninguém mediu.

### Testes

`progteste`: **28 verificações, 0 falhas**. Regressão: `portateste`, `anomteste`,
`difteste`, `v50`, `qual` — 0 falhas.

### Ainda não feito deste prompt

Partes 2 (objetivo final) e 3 (marcos intermediários). O objetivo final **já
existe** — `telaResgate()` no dia 12, o caminhão do Exército, com quatro finais.
Aprofundar isso é trabalho separado e não foi começado.

---

## v54 — a silhueta debaixo da porta

`s27-porta.js`, com `PORTA_CFG`.

### A tensão de design, dita em voz alta

Foi pedido que cada anomalia fosse **"reconhecível de relance"**. Ao pé da letra,
isso **mata o jogo**: a dúvida na porta é o coração dele, e se dá pra identificar
a coisa num relance não existe dilema — é só olhar e decidir.

O que fiz no lugar: a sombra dá **categoria, não identidade**. Você vê que tem
coisa alta demais, ou baixa e comprida, ou larga demais pro vão, ou mais de uma.
É o bastante pra desconfiar e escolher olhar; não é o bastante pra ter certeza.

**Quinze criaturas caem em seis formas**, e compartilhar é de propósito.

| forma | criaturas | como se lê |
|---|---|---|
| gente | vizinho, mae, casca, fome | duas manchas de sapato |
| alto demais | alto, magro, dobra | manchas estreitas, sombra longa no chão |
| baixo e comprido | rastejo, raiz | a fresta some quase inteira |
| largo demais | inchado, batedor | vai de um batente ao outro |
| mais de um | matilhaC, crianca | mais pés do que cabe numa pessoa |
| não dá pra dizer | fundo, aquilo | não fecha formato nenhum |

### O que não foi mexido

O olho mágico **já tinha** revelação progressiva por zonas, e as 15 criaturas
**já tinham** defeitos próprios (`DEFEITO_CRIATURA`). Isso funciona e ficou como
estava. O que faltava era a sombra debaixo da porta — a primeira coisa que você
vê, antes de decidir se vale gastar o olho mágico — que era retângulo preto igual
pra todo mundo.

### Ritmo de batida por forma

Largo bate forte e devagar (`0s 0.9s`, força 1.5); rastejo bate fraco e miúdo
(`0s .16s .30s .52s`, força .55); "errado" bate fora de qualquer tempo
(`0s .31s .37s 1.1s`). Seis compassos, nenhum repetido.

### Escala relativa, verificada

Medido em **320, 390, 540, 768 e 1080 px**: nenhuma forma sai do canvas e nenhuma
escapa do enquadramento da porta, nem no pior caso do balanço.

### Galeria

    portaGaleria()          as seis formas lado a lado, no canvas do jogo
    portaMostrar('inchado') põe aquela criatura na porta agora

A galeria é **no canvas do jogo**, não numa página separada — página separada
teria de copiar a tabela `FORMA`, e cópia diverge do original no primeiro ajuste.

### Dois defeitos que os testes acharam

1. **Eu chutei a geometria da porta.** A primeira versão usava `w*.52` e `h*.12`;
   os valores reais são `Math.min(w*.60,h*.52)` e `h*.055`, com `chao=h*.90`. A
   mancha saía deslocada. Agora está copiada linha por linha do original, com o
   endereço no comentário.
2. **A medição de custo deu número negativo** (−0,8 ms: desenhar com a sombra
   "mais rápido" que sem). Era aquecimento de JIT. Com aquecimento e medindo nas
   duas ordens: **0,024 ms**, dentro do próprio ruído das amostras — o que é uma
   afirmação mais forte que "menos de 1 ms".

**Isto é proxy, não medição em celular.** Não há instrumentação de quadro no
projeto e eu meço em Chromium headless num servidor.

### Testes

`portateste`: **17 verificações, 0 falhas**. Regressão: `anomteste`, `difteste`,
`fugateste`, `v50` — 0 falhas. `varre`: 184 cliques, 0 estouros.

---

## v53 — as anomalias viram a ameaça

`s26-anomalias.js`, com `ANOM_CFG`. A dificuldade vem do §25 — este bloco
**não cria multiplicador próprio**, como foi pedido.

### O que existia

Seis criaturas com nome, aparência e uma frase de fraqueza — e **uma perseguição
só para todas**: `moverMonstro` andava pro vizinho mais perto de `I.ruidoEm`
enquanto `I.memoria > 0`, senão sorteava. `vel` e `mem` só mudavam números dentro
dessa mesma regra, e o campo `fraco` era **texto exibido, nunca regra**.

### Ciclo de estado explícito

```
RONDA → SUSPEITA → CACA → PERDEU → (volta a RONDA)
```

`PERDEU` é fase de verdade: ela vasculha **em volta** do último lugar conhecido
antes de desistir. Há teto de turnos em `CACA` — nenhuma perseguição é eterna — e
`cooldown` depois de desistir, que é a janela de respiro do jogador.

### Regra única por criatura, com contra-jogo descobrível

| criatura | reage a | contra-jogo |
|---|---|---|
| o Magro | **luz** | não entra em cômodo aceso; a lanterna o afasta |
| o que Rasteja | **rastro** | ignora barulho, segue por onde você pisou |
| Muitas Bocas | **som** | barulho alto separa as duas metades |
| o que Chama | **resposta** | sem resposta vai pro barulho; responder entrega sua posição exata |
| o Inchado | **passagem** | perde turno em cômodo apertado |
| aquilo | **olhar** | olhar direto o aproxima e custa sanidade |

A dica de cada uma aparece em **"Escutar onde ele está"** — descoberta jogando,
sem wiki.

### Aviso antes do dano, garantido

Um turno antes de encostar, a criatura é **obrigada** a emitir sinal, com texto
próprio por criatura. `ANOM_CFG.distanciaAviso` nunca pode ser zero.

### Presença fora do combate

Cada criatura deixa uma marca diferente na casa, e a marca **ainda está lá dias
depois** — aparece ao entrar no cômodo, com quanto tempo faz. Teto de 6 marcas.

### Dois bugs que o teste de 2000 turnos achou — e que teriam passado

O teste roda cada criatura por 2000 turnos e acusa se alguma passa 200 turnos
seguidos na mesma fase. Ele pegou **duas criaturas completamente inertes**:

1. **O imitador ficava preso em RONDA pra sempre.** A primeira versão fazia ele
   ignorar ruído enquanto `respondeu` fosse falso — e nada no jogo jamais setava
   esse campo. Corrigido: ele ouve como as outras, e o que a resposta muda é a
   **precisão** (barulho vs. sua posição exata). O chamado também virou mecânica
   de verdade: antes era só texto de clima dentro de `turnoMonstro`, sem marcar
   nada.
2. **O rastejante ficava preso em RONDA pela mesma razão estrutural.** Ele recusa
   som (certo) e não tinha nenhuma outra porta de entrada (errado). Ganhou
   `anomPisou()`: quem lê o chão acorda quando você anda, não quando você faz
   barulho.

Uma criatura que nunca sai de ronda é uma criatura que não existe. As duas teriam
sido publicadas inofensivas.

### Debug

    anomInvocar('coro')    começa uma invasão com aquela criatura
    anomEstado(I)          fase, turnos, trilha, cooldown, marcas

### Testes

`anomteste`: **28 verificações, 0 falhas**. Regressão: `difteste`, `fugateste`,
`expteste`, `v50`, `qual` — 0 falhas. `varre`: 205 cliques, 0 estouros.

---

## v52 — curva de dificuldade

Multiplicador **único e centralizado** em `s25-dificuldade.js`, com `DIF_CFG`.

    dia 1 → 0.60     sobe (smoothstep, 12 dias)     satura → 0.80

Nunca volta a 1.00, nunca passa de 0.80. A redução permanente de 20% é o teto;
os 40% do dia 1 são a rampa.

### Cinco pontos de aplicação, um embrulho cada

| função | o que controla | modo |
|---|---|---|
| `riscoInvasao` | frequência das anomalias | direto |
| `escassez` | escassez de recursos | direto |
| `pegarMal` | dano recebido (duração do mal) | direto |
| `gastoComida` | custo de fome | direto |
| `folegoPorta` | agressividade suportada | **inverso** |

**Por que `folegoPorta` é inverso:** ele diz quantos encontros você aguenta numa
invasão. Multiplicar por 0.60 ali teria deixado o jogo **mais difícil**, não
menos. Existe `difInverso()` separado, com nome diferente, pra ninguém aplicar o
errado por distração.

### Prova de que não há dupla aplicação

O teste instrumenta `dif()` e conta quantas vezes ela é chamada por invocação de
cada função embrulhada. **Todas devolvem exatamente 1.** Além disso
`embrulharUmaVez()` recusa um segundo embrulho e avisa no console — o teste
tenta embrulhar `escassez` de novo e prova que o valor não muda.

### Uma coisa que foi pedida e NÃO existe neste jogo

**"Tempo de reação exigido em eventos".** Não há nenhuma decisão com prazo: o
jogo é de menu e espera indefinidamente pelo toque. A varredura achou um único
`setTimeout` resolvendo promessa, e é o vigia anti-travamento. A tela do resgate
diz "você tem uns quarenta segundos pra decidir", mas é texto — não há contagem.
Está declarado em vez de fingido. Se um dia existir decisão com prazo, ela usa
`difInverso()` e nada mais precisa mudar.

### Um defeito que o teste achou

`dificuldadeNoDia(1e9)` saturava em 0.80 mas `dificuldadeNoDia(Infinity)` caía
em 0.60 — duas respostas opostas para "número absurdo". A regra virou explícita:
**não-número é save corrompido e cai no dia 1** (o mais fácil: diante de estado
quebrado o benefício é do jogador); **número válido, ainda que absurdo, satura**.

### Save

Nada a migrar. A dificuldade é função pura de `S.dia`, que todo save já tem.
Quem estava no dia 7 entra na curva no ponto do dia 7 — nem punido nem
presenteado. Guardar o multiplicador no save criaria um segundo lugar onde a
verdade mora, e um save velho ficaria preso numa curva antiga pra sempre.

### Debug

    difDia(20)     pula pro dia 20 e mostra o multiplicador na tela
    difTabela()    imprime a curva inteira
    difEstado()    dia, valor, inverso, config e os cinco pontos

### Testes

`difteste`: **24 verificações, 0 falhas**. Regressão: `fugateste`, `expteste`,
`v50`, `qual` — 0 falhas.

---

## v51 — auditoria, expedição transacional e fuga jogável

Quatro fases, quatro commits. O resumo do que quebrou, por que quebrou e o que
mudou.

---

### O que quebrou, e por quê

**O jogador saía pra rua, achava coisas, e voltava pra casa sem nada — com uma
tela dizendo "O jogo travou aqui".**

A causa não era o que parecia. Não era exceção no código de coleta, não era save
sobrescrito, não era sprite faltando (este jogo não usa sprite nenhum). Era uma
**colisão de nome global**.

O jogo é distribuído como um HTML só, e `montar.js` injeta 14 blocos `.js` dentro
dele. Todos compartilham **um escopo global único**: 1 200 nomes de topo num
espaço só. Quando dois blocos escolhem o mesmo nome sem saber um do outro, o
segundo apaga o primeiro — **sem erro nenhum na carga**.

Foi o que aconteceu duas vezes:

| nome | o que era | o que passou a ser |
|---|---|---|
| `capacidade` | quantos **quilos** você carrega na expedição, recebe o **parceiro** | quantos **slots** um baú tem, recebe o **id do baú** (§16) |
| `ficha` | desenha uma **linha de tela** `(nome, tag, texto)` | devolve a **ficha de personagem** `()` (§19) |

A primeira colisão fazia `etapaCarga` chamar `BAUS[parceiro].slots` na sua
primeira linha — antes até de `limpar()`. Por isso a tela nem trocava: o jogador
ficava olhando o texto do saque com a barra de ações vazia, até o vigia disparar
14 segundos depois. E como o saque só era creditado no **fim** de `recolher()`,
voltar pra casa pelo botão do vigia significava perder tudo.

Medido: **28 estouros em 63 expedições**. Praticamente toda saída pra rua que
chegava na tela de carga.

A segunda colisão era silenciosa de outro jeito: 20 e tantas listas do jogo
— gente no abrigo, itens do saque, bancada de armas — simplesmente **pararam de
desenhar**.

Nenhuma das duas apareceu em teste nenhum durante versões inteiras, porque
nenhuma produz erro.

---

### O que mudou

#### Fase 0 — auditoria (`docs/AUDITORIA.md`)
Mapa da arquitetura, da máquina de estados, dos nove depósitos de inventário,
dos pontos de save, dos teleportes e dos acoplamentos indevidos. Nenhuma linha de
código alterada. Veredito das seis hipóteses do briefing: **H2 confirmada**, H1
confirmada em parte, H3/H4/H5/H6 descartadas como causa.

#### Fase 1 — a expedição parou de comer o saque
- `s16`: `capacidade` → **`capacidadeBau`**
- `s19`: `ficha()` → **`fichaJogador()`**
- **`montar.js` quebra o build** se um nome novo colidir. As cinco substituições
  deliberadas estão declaradas em `COLISAO_OK`, cada uma com o motivo escrito.
- **`s23-expedicao.js`** (novo): o saque virou transacional. O `levar` deixou de
  ser variável local e passou a ser `S.exped.levar`, **dentro do estado salvo**.
  Mesma referência de objeto, então a fuga que corta 40% e o susto que corta pela
  metade continuam funcionando sem uma linha alterada.
  - cada pegada marca o save: o que está na sua mão está no disco
  - travou no meio? na próxima abertura o saque volta com você
  - `socorro()` deixou de descartar trabalho: credita antes de levar pra casa
  - achado sem nome, sem quantidade ou com peso `NaN` é registrado e ignorado
  - erro parou de ser engolido: console com contexto + anel de 20 em `S.erros`

#### Fase 2 — varredura (`docs/BUGS.md`)
755 cliques aleatórios em 5 sementes, com toda função global embrulhada num
`try/catch` que denuncia quem estoura, e invariantes checados a cada 20 cliques.
Depois da Fase 1: **0 estouros, 0 invariantes violados, 0 travamentos**.
- **Backup do save**: eram 7 gravações por save, uma por bloco, sem nenhuma cópia
  de segurança. Agora o conteúdo anterior vai pra uma chave de sombra antes da
  primeira gravação (uma escrita por save, não sete), e a carga cai pro backup se
  o principal estiver ilegível.

#### Fase 3 — fugir deixou de ser derrota
`mover()` terminava com `if(PLANTA[dest].saida) return escapou(I)`, e `escapou()`
terminava em `fim('fuga')`. **Andar pro quintal durante uma invasão acabava a
partida.**

**`s24-fuga.js`** (novo) transforma isso num estado com fases legíveis:

```
INVADINDO → VASCULHANDO → SAINDO → SEGURO → RESET
```

- **Quintal e rua são áreas jogáveis**, cada uma com ações próprias: esperar e
  escutar, se enfiar mais fundo no esconderijo, trocar de área, espiar a casa por
  uma fresta, entrar.
- **A regra que faz isso ser jogo:** se ela sai **pelos fundos**, o quintal fica
  perigoso; se sai **pela frente**, a rua. Você ouve pra onde ela está indo e
  escolhe onde esperar.
- **A casa é desenhada de fora**, e a janela do cômodo em que ela está acende com
  a silhueta atravessando. É o "observar a silhueta se movendo" pela via que este
  projeto tem — não há mundo 3D aqui.
- **Nunca machuca sem avisar:** o primeiro erro é susto ("ela cheira o ar, você
  não respira, ela segue"). Só o segundo cobra, e mesmo assim fere e empurra pro
  outro lado — não mata.
- **Consequências em vez de derrota:** ela leva comida, diesel, remédio ou item
  da mochila; arrebenta muro, calha, tábua ou armadilha; acha quem ficou
  escondido. Ficar muito tempo fora custa sanidade, e a volta custa comida.
- **`FUGA_CFG`** concentra todo tempo, chance e custo, cada um comentado. Nenhum
  número solto no meio da lógica.

#### Fase 4 — testes
| suíte | verificações |
|---|---|
| `expteste` — expedição transacional | 19, 0 falhas |
| `fugateste` — ciclo da invasão e fuga | 30, 0 falhas (estável em 3 voltas) |
| `baktest` — backup do save | 6, 0 falhas |
| `varre` — varredura ampla | 0 estouros, 0 invariantes violados |
| regressão: `v50`, `v49`, `qual`, `equipteste`, `menuteste`, `corte`, `gerteste`, `am` | 0 falhas |

---

### Migração de save

Os campos novos (`exped`, `erros`, `fuga`) **não existem** num save antigo, e a
ausência já é o estado correto: ninguém estava no meio de uma expedição nem do
lado de fora de casa. Nada a converter, nada quebra.

---

### Mudanças que quebram compatibilidade de API

Se você tinha código ou teste chamando estes nomes, precisa atualizar:

| antes | agora |
|---|---|
| `capacidade(idDoBau)` | `capacidadeBau(idDoBau)` |
| `ficha()` (ficha de personagem) | `fichaJogador()` |

`capacidade(parceiro)` e `ficha(nome, tag, texto)` voltaram ao significado
original.

---

### O que ficou aberto

- **`cena.modo` é sobrecarregado.** `'vazio'` significa ao mesmo tempo "estou num
  cômodo" e "estou numa cena de corte". 28 pontos de escrita. Já causou três bugs
  distintos. Separar em `modo` + `jogavel` mexe em 28 lugares e o risco é maior
  que o ganho nesta rodada.
- **`sustoAntigo()` é código morto** (`index.html:10172`, começa com
  `if(true)return false`).
- **Não medido:** FPS e memória em sessão longa, outros navegadores, e se alguma
  colisão existe dentro de objetos (`X.metodo = ...`) — a trava só pega
  declarações de topo.
