# Auditoria do ULTRA_PROMPT V72 contra o código que existe

*O §1 manda auditar antes de escrever, e o §2 diz “não duplique sistemas
existentes”. Nas três rodadas anteriores desta sessão a coisa pedida já existia
duas vezes e meia — e uma vez eu não olhei, escrevi por cima de algo melhor, e
entreguei pior. Então aqui está a medição, com número, antes de uma linha.*

---

## Em uma página

| § | o que o documento pede | situação medida |
|---|---|---|
| 3 | Diretor de Terror Dinâmico | **existe** como `s31-orquestrador.js` — mas **não lê o jogador** |
| 4 | Terror psicológico (discrepâncias, imitação, presença, dúvida) | **existe**, espalhado por §49, §40, §32 e as seis criaturas |
| 6 | Sistema de Presença | **meio existe** — é canal de rastro e é tell; não é percepção sem entidade |
| 7 | Entidades que fingem ser aliadas | **existe e é forte** |
| 8 | Mentiras e informação não confiável | **existe** — §44, com uma regra falsa por campanha |
| 10 | Sistema de Marcas | **existe uma, completa.** E o nome colide com dois outros conceitos |
| 11 | Eventos extremamente raros | **não existe** — “raro” no código é faixa de loot |
| 12 | Áudio espacial e silêncio | espacial **existe** (§47); silêncio como estado de áudio **não** |
| 13 | Sistema de Trauma | **não existe pro jogador** — `traumatizado` é temperamento de NPC |

---

## 1 · O Diretor já existe — e está surdo

O §3 pede um Diretor com orçamento de intensidade, cooldowns, tags de
incompatibilidade, pesos configuráveis, anti-repetição, RNG reproduzível, logs e
testes de distribuição. Isso é a descrição do `s31-orquestrador.js`, escrito na
v58:

```
orcamentoBase 100, +2,5/dia, teto 160     ← orçamento de intensidade
cooldownCategoria 6 · cooldownGlobal 2    ← cooldowns
podeCoexistir(a,b)                        ← tags de incompatibilidade
prioridade{primordial:100 … ambiental:10} ← preempção, com deltaPreempcao 25
memoriaEventos 6 · penalRepeticao .25     ← anti-repetição
bonusAdiado .45 (teto 1.8)                ← o que foi negado volta mais forte
valesPorNoite 2 · valeDuracao [4,7]       ← vales de SILÊNCIO
densidadeAlvo [4,8]                       ← faixa alvo, com orqSimular/orqHistograma
```

Ele até já tem a ferramenta que o §16 pede: `orqSimular(noites, seed)` e
`orqHistograma`.

**O que falta é o achado desta auditoria.** O jogo tem duas metades de Diretor e
elas não se falam:

- `s31-orquestrador.js` decide **o que acontece** — mas só olha para eventos.
- `pressaoAgora()` (§42) mede **como o jogador está** — tempo fora do núcleo,
  ruído, luz, exposição, com quatro degraus.

E `pressaoAgora()` é consultada por **exatamente uma coisa em todo o projeto**:
as costuras do §49, escritas ontem. Medido:

```
grep 'pressaoAgora()' *.js  →  s49-costuras.js:185      (uma linha, só)
grep 'pressaoAgora'  s31-orquestrador.js  →  0
```

O Diretor de eventos nunca soube que o jogador estava com medo. É exatamente o
que o §3 quer que ele saiba, e é um fio, não um sistema novo.

Falta também a máquina de estados nomeada — `CALMO → SUSPEITO → TENSO → PERIGO →
PÓS-CLÍMAX → RECUPERAÇÃO`. O orquestrador tem orçamento e vales, mas não tem a
noção de **pós-clímax**: depois de uma noite pesada ele não recua de propósito.

---

## 2 · O “Sistema de Marcas” já existe — e o nome colide com outros dois

Isto precisa ser dito antes de qualquer código, porque o projeto tem uma trava de
build que quebra em colisão de nome, e ela já salvou quatro etapas.

**Três conceitos diferentes disputam a palavra “marca”:**

| no código | o que é |
|---|---|
| `marcas()` / `S.marcasCasa` | a **evidência** que uma criatura deixa no cômodo, uma por criatura, que reaparece dias depois |
| `S.marcado` / `pesoMarca()` | **A Marca** — a consequência persistente de contato com o anômalo |
| `marcarCicatriz` (§45) | a **cicatriz** de ferimento, que a casa passa a mirar |

E o `S.marcado` é quase exatamente o que o §8 descreve. Ele já tem:

- **origem e gatilho** — falhar em certos eventos liga `S.marcado=true`;
- **estágio** — `S.marcaDias`, com seis falas em dias diferentes:
  > *“Alguma coisa passou a saber onde você dorme. Você não sabe como sabe disso.”* (dia 1)
  > *“Você escreve o seu nome e sai errado. Você escreve de novo e sai certo.”* (dia 12)
  > *“Tem uma coisa que anda com você de cômodo em cômodo. Nunca à sua frente.”* (dia 16+)
- **efeitos** — `+2` de ruído por dia, `pesoMarca()` de 12% a 35% pior em
  investigar, e o canal de rastro `PRESENCA` salta de 3 para **12**;
- **remoção** — três caminhos, com 35%, 55% e 48%;
- **persistência** — `marcado` e `marcaDias` no save.

O que o §8 pede e não existe: **ser mais de uma**. Marca do Observador, do
Ritual, do Eco. O trabalho honesto é generalizar a que existe, não escrever uma
segunda ao lado dela.

---

## 3 · O que de fato não existe

**Eventos raros (§11).** As 138 ocorrências de “raro” no código são **faixas de
loot** (`/* ---------- raros ---------- */`, `/* ---------- muito raros ---------- */`)
e a raridade formal de item do §36. Um sistema de *evento* raro, com
anti-repetição entre campanhas e categorias A–E, não existe.

**Silêncio como estado de áudio (§12).** A parte espacial foi feita no §47:
absorção de ar por cômodo, seis superfícies de piso, distância em `saida()`. E o
orquestrador tem **vales de silêncio** — mas eles calam *eventos*, não o *som*. O
mixer de 5 camadas do §47 está pronto para isso e ninguém pediu silêncio a ele.
Os quatro tipos que o §12 quer — natural, de presença, anômalo, pós-evento — não
existem.

**Trauma do jogador (§13).** `traumatizado` é um **temperamento de morador**
(“quem viu demais”), com banco de falas próprio. O jogador tem sanidade em
estágios (§38) e cicatriz (§45) — mas não tem experiência registrada com gatilho:
“você foi perseguido no porão” não muda como o porão soa depois.

**Presença sem entidade (§6).** Existe `PRESENCA` como canal de rastro em
`v9Rastros` (peso 3, ou 12 se marcado) e existe o tell obrigatório `avisoDe`. Não
existe presença **com falso positivo declarado** e assinatura diferente por
fonte, que é o coração do §6: *“nem todo evento estranho é ameaça”*.

---

## 4 · Riscos

1. **Colisão de nome.** `marca`, `presenca`, `diretor`, `trauma`, `silencio` e
   `raro` são todos nomes prováveis de colisão. A trava de build pega — mas
   melhor escolher antes do que descobrir no build.
2. **Empilhamento.** O §18 exige que “eventos não dominem a experiência”. O jogo
   já tem orquestrador com orçamento, costuras com teto de 2/dia, e pressão. Um
   Diretor novo por cima disso é o caminho mais rápido para a feira de sustos.
   Por isso a Etapa 1 é *ligar* o que existe, não empilhar.
3. **`cena.modo` continua sobrecarregado**, declarado em aberto desde a v71.

---

## 5 · O plano

| etapa | o que entra | por quê nesta ordem |
|---|---|---|
| **1** | **O Diretor ganha ouvido**: `pressaoAgora()` passa a alimentar o orquestrador, e entram os estados nomeados com **pós-clímax e recuperação** | é um fio, não um sistema; e tudo o mais pendura nele |
| **2** | **Silêncio como estado de áudio** — os quatro tipos, no mixer que o §47 deixou pronto, dirigidos pelo estado do Diretor | o §2 diz que silêncio é ferramenta, e é o efeito mais barato e mais forte |
| **3** | **Presença** com falso positivo e assinatura por fonte | depende de 1 e 2 |
| **4** | **Marcas no plural** — generalizar a que existe — e **trauma do jogador** | consequência persistente |
| **5** | **Eventos raros**, categorias A–E, com anti-repetição entre campanhas | o fecho, e o mais fácil de errar sozinho |

Cada etapa: medir → envelopar o que existe → testar com recarga real → site
animado → commit.

---

## §52 · O silêncio vira estado do som (feito)

### O que já existia

O jogo **já trata silêncio como conteúdo**. O orquestrador agenda "vales de
silêncio" **antes** de qualquer evento — dois por noite, de quatro a sete turnos
cada — e o comentário dele diz em letras claras: *"valeObrigatorio não é ausência
de evento: é evento"*. Existe também `silencioSubito(seg)`, o corte de mestre
usado como arma em 12 lugares.

### O que faltava, medido

O áudio não sabia de nada disso. Medido turno a turno, atravessando um vale de
verdade:

| turno | vale | AMBIENCE | leito | corte | mestre |
|---|---|---|---|---|---|
| 2 | não | 0,07943 | 0,07 | 260 Hz | 0,9 |
| 5 | **sim** | 0,07943 | 0,07 | 260 Hz | 0,9 |
| 9 | não | 0,07943 | 0,07 | 260 Hz | 0,9 |

Byte por byte igual. `emVale()` era consultado só pelo `pedirPermissao`: o vale
existia na agenda de eventos e **não existia no ouvido**. O jogador atravessava o
silêncio sem ouvir silêncio nenhum.

### O que entrou

Três estados declarados, e o som muda de verdade entre eles:

| estado | quando | AMBIENCE | MUSIC | leito | corte |
|---|---|---|---|---|---|
| **CHEIO** | fora do vale | ×1 | ×1 | 0,0700 | 260 Hz |
| **RAREFEITO** | no vale | ×0,42 | ×0,30 | 0,0315 | 187 Hz |
| **OCO** | no vale, com pressão alta | ×0,16 | ×0,08 | 0,0126 | 117 Hz |

O filtro **fecha** conforme afunda: não é só mais baixo, é mais longe. Baixinho e
perto é sussurro; baixinho e longe é a casa se afastando de você.

**SFX e HORROR não são tocados, de propósito.** O vale serve para que, quando a
coisa acontecer, ela aconteça contra um fundo fino. Abafar o susto junto mataria
o motivo de existir o vale. Medido: SFX 0,316228 e HORROR 0,398107 idênticos em
CHEIO e em OCO, enquanto o ambiente cai de 0,079433 para 0,012709.

**O tell.** A regra de ouro exige que o jogador consiga explicar depois. Duas
coisas fazem isso: o vale sempre desemboca em alguma coisa, então "ficou quieto
antes" vira aprendizado; e ao afundar no OCO o jogo diz uma linha, uma vez por
afundada, e outra na volta. Trilha medida de uma noite:

```
-C -C vO vO vO vO vO -C -C -C -C -C -C -C -C vO vO vO vO -C
entrou no OCO 2× · saiu 2× · falou de entrada 2× · de volta 2×
```

### Onde o abaixamento mora, e por quê

Não no ganho do canal. `amDuck` faz rampa de volta para o cheio, então qualquer
abaixamento sustentado deixado em `AM.canais[c].gain` seria apagado no primeiro
duck. Entra um nó novo entre o canal e o mestre — `canal → silêncio → mestre`.
Cada um escreve no seu e os dois se multiplicam sozinhos, que é como insert de
mesa funciona.

### Três erros meus, e o que os pegou

1. **Uma linha de texto estava mudando o jogo inteiro.** A escolha da fala usava
   `sortear`, que consome o gerador semeado compartilhado: cada fala empurrava a
   sequência um passo e **todo sorteio seguinte da noite saía diferente**. O
   `dirteste` reprovou três asserções; rodei o build anterior nas mesmas três e
   elas passavam — a prova de que era meu. Coisa cosmética escolhe por índice
   determinístico, não por sorteio.
2. **`dirCalcular()` não é consulta, é passo.** Ele empurra a média acumulada do
   diretor a cada chamada. Perguntar o estado uma vez por turno dobrava a
   velocidade de convergência do humor da campanha. O getter puro é
   `dirEstadoBruto()`.
3. **A trava de colisão do `montar.js` quebrou o build na hora** porque o §51 já
   usava `SIL_CFG`. Dois blocos com o mesmo nome de topo fazem o segundo apagar o
   primeiro em silêncio — exatamente o tipo de erro que não dá erro.

### Dois erros no meu próprio teste

- **Eu media o nó errado e no tempo errado.** Lia `AM.canais.AMBIENCE.gain`
  (onde o abaixamento não mora) e esperava 120 ms com uma rampa de 3,4 s, então
  media sempre o meio da rampa.
- **Asserção que não pode falhar não é asserção.** "O susto não é abafado junto"
  lia o ganho do canal SFX, que por desenho nunca é tocado: passava até na
  regressão plantada em que eu de propósito abafei o SFX. Agora mede o ganho
  efetivo do caminho, canal × insert.

### O que foi provado

`tools/testes/silencioteste.mjs`, 25 asserções. Regressões plantadas e pegas:
`silenAplicar` desligado (o áudio volta a ser idêntico dentro e fora do vale, 3
asserções caem) e insert posto em SFX/HORROR (3 caem). O bloco **não grava campo
nenhum no save** — o estado é derivado — e **não consome um passo do gerador**
(medido: 3042454019 antes e depois de uma atualização que mudou o estado e falou).
Regressão geral: 13 harnesses verdes.

---

## §53 · A presença, e como saber se ela é sua (feito)

### Pela quinta vez, metade já existia

O §6 pede "presença com falso positivo declarado e assinatura por fonte". O falso
positivo declarado **já existe e é bom**: `ILUSOES_SOM` tem nove ilusões em três
trilhos, cada uma com texto de `real`, de `falso` e de `ignora`, e a chance de ser
real cai junto com a cabeça. Medido estágio por estágio:

| estágio | chance de ser real |
|---|---|
| lúcido | *não acontece* |
| tenso | 54% |
| fissurado | 40% |
| rachado | 22% |
| desfeito | 6% |

### O que faltava, também medido

1. **No lúcido não acontece nada.** Quem se cuida nunca encontra o sistema.
2. **As nove são som.** `ilusões sem som: nenhuma`. Não existia presença que você
   *sente* em vez de ouvir — o buraco que a auditoria apontou.
3. **Não havia assinatura para aprender.** O `trilho` é interno.

### O que entrou — e o que de propósito não entrou

**Não entrou um sistema de eventos novo.** Esta própria auditoria avisa que
empilhar evento sobre orquestrador, costuras, pressão e diretor é o caminho mais
curto para a feira de sustos. O §53 é uma **lente**: lê estado que já existe, não
agenda nada, não gasta orçamento e não compete por turno.

**Quatro fontes, cada uma com a assinatura que a denuncia** — e a assinatura é o
comportamento, não uma tabela que o jogo mostre:

| fonte | como ela se comporta | medido |
|---|---|---|
| **PORTA** | tem direção e fica onde está | aparece igual em qualquer cômodo |
| **DENTRO** | te acompanha de cômodo em cômodo | DENTRO nos 3 cômodos testados |
| **LUGAR** | é do cômodo, não sua | LUGAR no cômodo dela, nada em outro |
| **VOCE** | sem direção, varia entre visitas, cede quando você confere | acendeu 29 de 40 visitas no pior caso, e variou |

**O falso positivo nunca é sorteio.** Ele só acontece quando a condição do jogador
explica, e cada causa tem nome que entra na frase:

| condição | chance | causa nomeada |
|---|---|---|
| inteiro, de dia, com lanterna | **0** | — |
| cabeça ruim | 0,55 | a sua cabeça |
| ferido | 0,25 | a ferida |
| no escuro | 0,30 | o escuro |
| no silêncio oco (§52) | 0,25 | o silêncio |
| tudo junto | 0,72 *(teto)* | as quatro |

É isso que satisfaz a regra de ouro: depois do fato o jogador sempre consegue
dizer por quê. Sorteio puro seria exatamente o erro proibido — *"se um evento não
puder ser explicado pelo jogador depois que ele acontece, o evento está errado"*.

**O de verdade sempre ganha do inventado.** Com a cabeça no fundo do poço e nada
na casa, a leitura é VOCE. A mesma cabeça, com bicho dentro, lê DENTRO com força
0,9. Medido.

**Conferir é o contra-jogo**, e entra no `menuRealidade`, que já é o lugar de
"conferir a realidade" — não numa tela nova. O falso cede e diz o porquê; o
verdadeiro continua.

### Quatro erros, três meus e um do teste

1. **Sombreei o acessor de sanidade.** `const san = (typeof san==='function')...`
   cai na zona morta temporal e o `typeof` **estoura**; parecia funcionar porque o
   `catch` pegava, e o `san()` de verdade nunca era consultado.
2. **O teste escrevia num campo somente-leitura.** `S.ferido` é derivado desde o
   §41 e recusa escrita de propósito. A causa "ferida" nunca acendia: **o teste
   estava errado e a guarda do jogo estava certa.**
3. **Filtro largo acusou inocente.** A checagem de "não sujou o save" usava
   `/^vig/i` e acusava `S.vigiou`, que é da base.
4. **Falei antes de redesenhar.** `limpar()` esmaece em vez de apagar, então a
   resposta do "conferir" nascia já apagada: o botão existia, o texto era escrito,
   e não dava para ler.

### O que foi provado

`tools/testes/vigiateste.mjs`, 19 asserções. Regressões plantadas e pegas: o falso
positivo virando sorteio sem causa (2 caem) e a cabeça ganhando do bicho de
verdade (5 caem). A leitura **não consome o gerador semeado** (medido idêntico
antes e depois de 50 leituras) e **não grava campo no save**. Regressão geral: 12
harnesses verdes.

---

## §54 · Marcas no plural, e o trauma que é de um cômodo (feito)

### O que existia

Uma marca só: o booleano `S.marcado` mais o contador `S.marcaDias`, rendendo
`pesoMarca()` de 0,12 a 0,35 conforme os dias, narração em marcos (dia 1, 4, 8,
12, 16), +2 de ruído por dia e três saídas no `menuMarca`.

O §8 pede plural. Esta auditoria já tinha escrito qual era o trabalho honesto:
*"generalizar a que existe, não escrever uma segunda ao lado dela"*. É o que foi
feito.

### As três

| marca | como você percebe | o que custa | peso |
|---|---|---|---|
| **do Olho** | você acorda virado pro outro lado da cama | pior em investigar, e elas aprendem mais rápido | 0,12 → 0,35 |
| **do Ritual** | quem reza na casa para de rezar perto de você | a casa desanima mais rápido do que devia | 0,06 → 0,22 |
| **do Eco** | você ouve a sua própria voz de outro cômodo | mais barulho do que você faz, e a porta aprende o seu nome | 0,04 → 0,18 |

Somam, com teto em 0,55 — três marcas não podem fazer um jogo impossível.

### O save antigo continua valendo, e o equilíbrio não mudou

Um save que só conhece `S.marcado=true, marcaDias=9` é lido como a marca do Olho
com 9 dias, e `pesoMarca()` devolve **0,228 — exatamente o que a fórmula original
devolvia**. Medido, com a fórmula antiga escrita de novo no teste só para
comparar. A marca do Olho continua usando a função original, letra por letra: uma
refatoração não pode mudar o jogo de quem já está jogando.

### O trauma é do cômodo, não da ficha

`traumatizado` no jogo é **temperamento de morador** — quem viu demais. O jogador
não tinha experiência registrada com gatilho. Agora tem, e ela mora no lugar
certo: você não ganha um número novo na tela, o **cômodo** é que fica pior.

- Nasce de coisa que já acontece: ferida grave (gravidade ≥ 2) no cômodo onde
  você está. Medido: `corte` (gravidade 1) não traumatiza; `cortefundo`
  (gravidade 3) traumatiza.
- É só daquele cômodo: força 1 no porão, 0 na sala.
- Pesa na lente do §53: mesma condição, a sensação média sobe de **0,72 para
  0,94** no cômodo do trauma.
- **Desbota**: 1 no dia, 0,5 em sete dias, 0 em catorze.
- E é anunciado na primeira volta, uma vez só: *"Você para na porta. Foi no porão
  que aconteceu, e o corpo lembra antes de você."*

### Dois erros, os dois no meu teste

1. **Comparei com o número que eu lembrava, não com o que medi.** Envelheci as
   marcas para 60 dias entre uma medida e outra e depois comparei contra o valor
   de antes: o Olho velho sozinho (0,35) é maior que as três novas (0,22).
2. **Afirmei sobre escrita que não é minha.** A checagem de "sem nome de jogador
   não grava" comparava o arquivo inteiro antes e depois, e reprovava por causa da
   gravação da BASE. O que este bloco pode prometer é que **o campo dele** não
   entra — e não entra.

### O que foi provado

`tools/testes/marcateste.mjs`, 18 asserções. Regressões plantadas e pegas: a
adoção do save antigo removida (2 caem) e o trauma virando global em vez de ser do
cômodo (2 caem). Regressão geral: 12 harnesses verdes, incluindo os três que
guardam save (`baktest`, `aberturateste`, `nucleoteste`).

---

## §55 · Eventos raros que continuam raros (feito)

### O achado foi maior do que esta auditoria supunha

Esta auditoria dizia que faltava "anti-repetição entre campanhas". Medido, faltava
antes disso: **a anti-repetição não funcionava nem dentro de uma campanha.**

| raridade | quantos | sem `id` (podem repetir) | peso |
|---|---|---|---|
| comum | 12 | 12 | 44 |
| incomum | 12 | 12 | 30 |
| raro | 9 | **9** | 17 |
| muitoraro | 6 | **6** | 7 |
| unico | 5 | 0 | 2 |

`sortearEvento` filtra por `S.usados.includes(e.id)` — e **só os cinco `unico` têm
`id`**. Os nove `raro` e os seis `muitoraro` nunca entravam na lista de usados.
Simulando 500 dias: dezesseis raros distintos, 91 saídas, e **o campeão apareceu
treze vezes**. Um evento cujo valor é ser raro saía toda semana.

### O conserto

Não foi editar 39 literais. Quando o evento não tem `id`, o id vem do **hash do
próprio texto** — estável entre execuções e entre campanhas, e nenhuma linha da
tabela precisou mudar. Depois: **20 raros distintos em 500 dias, 20 saídas, o mais
repetido saiu 1×.**

**Entre campanhas**, a memória vai numa chave própria do `localStorage`, fora do
save — save novo não pode apagar a lembrança da campanha passada, que é justamente
o ponto. E ela **não bane, pesa menos**: banir esvaziaria a sacola. Medido no pior
caso, com *todos* os raros marcados como recém-vistos, ainda saíram 5 em 200 dias
e o sorteio nunca voltou vazio. A lembrança envelhece: 1 → 0,833 depois de uma
campanha → 0 depois de seis.

**As cinco categorias** do §9: A estranho sem dano (9), B narrativo (2), C mistério
(6), D consequência futura (2), E ultrarraro (5). B e D estavam vazias depois do
adaptador — categoria declarada e vazia é parâmetro morto, a proibição nº 6 — então
entraram quatro eventos novos com condição específica. Os dois de **D** plantam
consequência usando sistema que já existe e que o jogador pode entender e desfazer:
a marca do Eco do §54, e o trauma de cômodo, que desbota sozinho.

### A trava que o §9 exige

*"Nunca usar evento raro para morte instantânea, softlock ou destruição de save."*
Isso não ficou como promessa: virou trava, com teste. Um evento assassino plantado
de propósito tenta zerar a vida e apagar o save; a trava devolve a vida a 1,
restaura o save e registra o incidente `{morreu:true, perdeuSave:true}`.

### Quatro erros meus

1. **Termo que se cancela.** A conta de rejeição era
   `_ale() >= fator*(1-v) + (1-v)*0 + v*fator`, que é `_ale() >= fator`: o quanto
   o evento tinha sido visto recentemente **não mudava nada**.
2. **Anotei no momento errado.** Gravava na memória dentro do sorteio, e o laço de
   rejeição sorteia várias vezes — candidatos descartados entravam como se o
   jogador tivesse visto.
3. **Deixei duas categorias vazias**, que é parâmetro morto.
4. **E o teste de segurança passou sem testar nada.** Eu trocava `window.chance`
   para furar o portão de 62% do `eventoDoDia`, mas `chance` é declaração de topo e
   não está em `window` (a armadilha do `CX` de novo): o evento nunca rodou, e "não
   matou / não comeu o save" passou porque **nada aconteceu**. Só a asserção que
   exigia o incidente registrado denunciou.

### O que foi provado

`tools/testes/raroteste.mjs`, 18 asserções. Regressões plantadas e pegas: a chave
derivada removida (o campeão volta a sair **73×**) e a trava de segurança removida
(vida 0, save apagado, 4 asserções caem). Regressão geral: 15 harnesses verdes.
